import type { FormEvent } from 'react';
import { useMemo, useState } from 'react';
import type { LucideIcon } from 'lucide-react';
import {
  ArrowLeft,
  Banknote,
  BarChart3,
  Building2,
  CheckCircle2,
  ChevronDown,
  ClipboardCheck,
  FileText,
  Handshake,
  Landmark,
  LockKeyhole,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  Scale,
  ShieldCheck,
  Sparkles,
  Target,
  Users,
  X,
} from 'lucide-react';

type CardItem = {
  icon: LucideIcon;
  title: string;
  description: string;
};

type FaqItem = {
  question: string;
  answer: string;
};

const company = {
  name: 'شركة التحصيل',
  slogan: 'متابعة المطالبات المالية باحترافية وهدوء',
  phoneDisplay: '+966 50 000 0000',
  phoneLink: '966500000000',
  email: 'info@example.com',
  location: 'المملكة العربية السعودية',
  workingHours: 'الأحد - الخميس، 9 صباحًا - 5 مساءً',
};

const navLinks = [
  { label: 'الرئيسية', href: '#home' },
  { label: 'من نحن', href: '#about' },
  { label: 'الخدمات', href: '#services' },
  { label: 'آلية العمل', href: '#process' },
  { label: 'السرية والامتثال', href: '#compliance' },
  { label: 'تواصل معنا', href: '#contact' },
];

const services: CardItem[] = [
  {
    icon: Banknote,
    title: 'تحصيل الديون التجارية',
    description:
      'متابعة المستحقات المتأخرة بين الشركات والموردين والعملاء التجاريين بأسلوب مهني يحافظ على العلاقة ويقلل النزاعات.',
  },
  {
    icon: Handshake,
    title: 'التسويات الودية وجدولة السداد',
    description:
      'التواصل مع الطرف المدين للوصول إلى حلول سداد واضحة وقابلة للتنفيذ قبل الانتقال لأي إجراء تصعيدي.',
  },
  {
    icon: ClipboardCheck,
    title: 'إدارة المطالبات المالية',
    description:
      'تنظيم بيانات المطالبة، فرز الحالات، تحديد الأولويات، وتقديم متابعة منظمة لصاحب المطالبة.',
  },
  {
    icon: FileText,
    title: 'تقارير متابعة دورية',
    description:
      'تزويد العميل بملخصات واضحة حول حالة كل مطالبة، آخر إجراء، الردود، والتوصيات المناسبة للمرحلة التالية.',
  },
  {
    icon: Scale,
    title: 'التوصية بالإجراء النظامي',
    description:
      'عند تعذر التسوية الودية، يتم توضيح الخيارات المناسبة للعميل وإرشاده إلى القنوات النظامية ذات العلاقة.',
  },
  {
    icon: LockKeyhole,
    title: 'حماية بيانات المطالبات',
    description:
      'التعامل مع بيانات العملاء والمستندات المالية بسرية تامة، مع حصر الوصول للأشخاص المخولين فقط.',
  },
];

const processSteps = [
  {
    number: '01',
    title: 'استلام الطلب',
    description: 'يتم استقبال بيانات المطالبة الأساسية وفهم طبيعة العلاقة وقيمة المستحقات والمدة الزمنية للتأخير.',
  },
  {
    number: '02',
    title: 'دراسة الحالة',
    description: 'نراجع المعطيات والمستندات المتوفرة لتحديد أفضل أسلوب للمتابعة الودية أو النظامية.',
  },
  {
    number: '03',
    title: 'التواصل المهني',
    description: 'يتم التواصل مع الطرف المدين بصياغة رسمية وهادئة تركّز على الحل والسداد لا على الضغط أو التشهير.',
  },
  {
    number: '04',
    title: 'التفاوض والتسوية',
    description: 'نقترح حلولًا عملية مثل السداد الكامل أو الجزئي أو الجدولة، وفق موافقة العميل وحدود الحالة.',
  },
  {
    number: '05',
    title: 'التقرير والإغلاق',
    description: 'يحصل العميل على نتيجة واضحة: تم التحصيل، تم الاتفاق، تعذرت التسوية، أو يوصى بالتصعيد النظامي.',
  },
];

const sectors = [
  'الشركات التجارية',
  'الموردون والمقاولون',
  'المؤسسات الصغيرة والمتوسطة',
  'مكاتب الخدمات',
  'الشركات الخدمية',
  'العيادات والمراكز الخاصة',
  'مزودو الاشتراكات والخدمات الدورية',
  'الجهات التي لديها مطالبات متكررة',
];

const whyUs: CardItem[] = [
  {
    icon: ShieldCheck,
    title: 'أسلوب رسمي يحمي السمعة',
    description: 'الرسائل والمتابعات تتم بلغة مهنية تراعي سمعة العميل وتحافظ على العلاقة التجارية قدر الإمكان.',
  },
  {
    icon: Target,
    title: 'تركيز على الحل لا التصعيد',
    description: 'نبدأ بالحلول الودية وجدولة السداد قبل أي مسار تصعيدي، لأن الهدف هو استرداد المستحقات بأقل ضرر ممكن.',
  },
  {
    icon: BarChart3,
    title: 'وضوح في المتابعة',
    description: 'كل حالة تحتاج معرفة: ماذا حدث؟ ما الرد؟ ما الخطوة التالية؟ لذلك صممنا العمل حول تقارير واضحة ومختصرة.',
  },
  {
    icon: Users,
    title: 'فهم لطبيعة الشركات',
    description: 'نتعامل مع المطالبات باعتبارها جزءًا من إدارة التدفق النقدي، وليس مجرد اتصالات عشوائية على المدينين.',
  },
];

const compliance: CardItem[] = [
  {
    icon: LockKeyhole,
    title: 'سرية المعلومات',
    description: 'لا يتم مشاركة بيانات المطالبات أو المستندات أو تفاصيل العملاء إلا ضمن نطاق الخدمة وبموافقة صاحب العلاقة.',
  },
  {
    icon: Scale,
    title: 'التزام بالإجراءات النظامية',
    description: 'يتم تقديم الخدمة بعبارات وإجراءات مهنية تتجنب التهديد أو التشهير أو استخدام أي أسلوب غير مناسب.',
  },
  {
    icon: FileText,
    title: 'توثيق واضح',
    description: 'يتم تسجيل مراحل المتابعة والنتائج والتوصيات لمساعدة العميل على اتخاذ قرار واضح في كل مرحلة.',
  },
];

const faqItems: FaqItem[] = [
  {
    question: 'هل الموقع مخصص لاستقبال ملفات الديون؟',
    answer:
      'هذه النسخة تعريفية وهدفها عرض الشركة واستقبال طلبات التواصل. يمكن لاحقًا إضافة نظام رفع ملفات أو لوحة متابعة حسب حاجة العميل.',
  },
  {
    question: 'هل يتم تحصيل الديون بطريقة قانونية؟',
    answer:
      'يجب أن تتم المتابعة بطريقة مهنية ومنظمة وبما يتوافق مع الأنظمة المعمول بها في بلد عمل الشركة. لا يتم استخدام عبارات تهديد أو تشهير أو أساليب مخالفة.',
  },
  {
    question: 'كم تستغرق عملية التحصيل؟',
    answer:
      'المدة تختلف حسب نوع المطالبة، جودة المستندات، تجاوب الطرف المدين، وقيمة المبلغ. لذلك تبدأ الخدمة عادة بدراسة الحالة ثم اقتراح مسار مناسب.',
  },
  {
    question: 'هل توجد رسوم ثابتة؟',
    answer:
      'الأفضل عدم عرض أسعار ثابتة في الموقع. يتم تحديد الرسوم أو العمولة بعد مراجعة ملف المطالبة وطبيعة الحالات وعددها.',
  },
  {
    question: 'هل بيانات العملاء والمطالبات آمنة؟',
    answer:
      'نعم، يجب التعامل مع كل البيانات بسرية، وعدم طلب مستندات حساسة عبر نموذج عام. عند الحاجة للمستندات يتم استخدام قناة تواصل رسمية وآمنة.',
  },
];

const stats = [
  { label: 'إجراءات منظمة', value: 'واضحة' },
  { label: 'بيانات العملاء', value: 'سرية' },
  { label: 'أسلوب التواصل', value: 'مهني' },
  { label: 'مسار العمل', value: 'موثق' },
];

function SectionHeading({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle: string }) {
  return (
    <div className="mx-auto mb-12 max-w-3xl text-center">
      <span className="section-eyebrow">
        <Sparkles className="h-4 w-4" />
        {eyebrow}
      </span>
      <h2 className="section-title">{title}</h2>
      <p className="section-subtitle">{subtitle}</p>
    </div>
  );
}

function ContactButtons({ compact = false }: { compact?: boolean }) {
  const message = encodeURIComponent('مرحبًا، أود الاستفسار عن خدمات تحصيل المطالبات المالية.');
  return (
    <div className={`flex flex-col gap-3 sm:flex-row ${compact ? 'sm:justify-start' : 'justify-center'}`}>
      <a className="primary-button" href={`https://wa.me/${company.phoneLink}?text=${message}`} target="_blank" rel="noreferrer">
        <MessageCircle className="h-5 w-5" />
        تواصل عبر واتساب
      </a>
      <a className="secondary-button" href={`tel:${company.phoneLink}`}>
        <Phone className="h-5 w-5" />
        اتصال مباشر
      </a>
    </div>
  );
}

function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  const closeMenu = () => setIsOpen(false);

  return (
    <header className="sticky top-0 z-50 border-b border-white/40 bg-white/85 backdrop-blur-xl">
      <div className="section-container flex h-20 items-center justify-between">
        <a href="#home" onClick={closeMenu} className="flex items-center gap-3" aria-label="الانتقال للرئيسية">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-900 text-lg font-extrabold text-white shadow-lg shadow-cyan-900/20">
            ش
          </div>
          <div>
            <p className="text-lg font-extrabold text-slate-950">{company.name}</p>
            <p className="text-xs font-semibold text-slate-500">{company.slogan}</p>
          </div>
        </a>

        <nav className="hidden items-center gap-7 lg:flex" aria-label="روابط الموقع">
          {navLinks.map((link) => (
            <a key={link.href} href={link.href} className="text-sm font-bold text-slate-600 transition hover:text-cyan-900">
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden lg:block">
          <a href="#contact" className="primary-button">
            اطلب استشارة
            <ArrowLeft className="h-4 w-4" />
          </a>
        </div>

        <button
          type="button"
          onClick={() => setIsOpen((current) => !current)}
          className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-800 lg:hidden"
          aria-label="فتح القائمة"
        >
          {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {isOpen ? (
        <div className="border-t border-slate-100 bg-white lg:hidden">
          <div className="section-container grid gap-2 py-4">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={closeMenu}
                className="rounded-2xl px-4 py-3 text-sm font-bold text-slate-700 transition hover:bg-slate-50 hover:text-cyan-900"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      ) : null}
    </header>
  );
}

function Hero() {
  return (
    <section id="home" className="relative overflow-hidden py-16 sm:py-20 lg:py-24">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top_right,rgba(14,116,144,0.12),transparent_35%),radial-gradient(circle_at_bottom_left,rgba(15,23,42,0.08),transparent_30%)]" />
      <div className="section-container grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
        <div>
          <span className="section-eyebrow">
            <ShieldCheck className="h-4 w-4" />
            حلول تعريفية رسمية لشركات التحصيل
          </span>
          <h1 className="max-w-4xl text-4xl font-extrabold leading-[1.25] tracking-tight text-slate-950 sm:text-5xl lg:text-6xl">
            حلول مهنية لتحصيل المستحقات المالية بطرق منظمة تحفظ السمعة والثقة.
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-9 text-slate-600">
            نساعد الشركات والمؤسسات على متابعة مطالباتها المالية من خلال إجراءات واضحة، تواصل مهني، تقارير متابعة، وحرص كامل على سرية البيانات.
          </p>

          <div className="mt-8">
            <ContactButtons compact />
          </div>

          <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:max-w-2xl">
            {['تواصل هادئ ورسمي', 'سرية في التعامل مع البيانات', 'تقارير متابعة واضحة', 'دراسة الحالة قبل تحديد الرسوم'].map((item) => (
              <div key={item} className="flex items-center gap-3 rounded-2xl border border-white/70 bg-white/70 p-4 shadow-sm">
                <CheckCircle2 className="h-5 w-5 flex-shrink-0 text-cyan-800" />
                <span className="text-sm font-bold text-slate-700">{item}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="relative">
          <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-cyan-600/10 blur-3xl" />
          <div className="absolute -bottom-8 -left-8 h-48 w-48 rounded-full bg-slate-900/10 blur-3xl" />
          <div className="relative overflow-hidden rounded-[2rem] border border-white/70 bg-white p-3 shadow-2xl shadow-cyan-950/10">
            <img src="./images/team.jpg" alt="فريق عمل في اجتماع مهني" className="h-[420px] w-full rounded-[1.5rem] object-cover" />
            <div className="absolute inset-x-6 bottom-6 rounded-3xl bg-slate-950/85 p-5 text-white backdrop-blur-md">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-500/20">
                  <Landmark className="h-6 w-6 text-cyan-200" />
                </div>
                <div>
                  <p className="text-lg font-extrabold">موقع رسمي يليق بمجال حساس</p>
                  <p className="mt-1 text-sm leading-6 text-slate-200">
                    التركيز على الثقة، النظام، السرية، وسهولة التواصل بدل العروض المبالغ فيها.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function TrustStrip() {
  return (
    <section className="py-8">
      <div className="section-container">
        <div className="grid gap-4 rounded-3xl border border-cyan-900/10 bg-white p-4 shadow-sm sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((item) => (
            <div key={item.label} className="rounded-2xl bg-slate-50 p-5 text-center">
              <p className="text-2xl font-extrabold text-cyan-900">{item.value}</p>
              <p className="mt-1 text-sm font-bold text-slate-500">{item.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="py-20 sm:py-24">
      <div className="section-container grid gap-10 lg:grid-cols-[0.95fr_1.05fr] lg:items-center">
        <div className="card p-8 sm:p-10">
          <span className="section-eyebrow">
            <Building2 className="h-4 w-4" />
            من نحن
          </span>
          <h2 className="section-title">واجهة رسمية لشركة تعمل في متابعة وتحصيل المطالبات المالية.</h2>
          <p className="section-subtitle text-right">
            يقوم هذا الموقع بتقديم الشركة بصورة مهنية تناسب طبيعة قطاع التحصيل: بدون مبالغة، بدون وعود غير موثقة، وبدون أسلوب ضغط. الرسالة الأساسية هي أن الشركة تساعد عملاءها على استرداد مستحقاتهم بطريقة منظمة تحفظ السرية وتراعي العلاقة التجارية.
          </p>
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {[
              'دراسة المطالبة قبل بدء المتابعة',
              'لغة رسمية ومهنية في التواصل',
              'حفظ مستندات وبيانات العملاء بسرية',
              'توصيات واضحة لكل حالة',
            ].map((item) => (
              <div key={item} className="flex gap-3 rounded-2xl bg-slate-50 p-4">
                <CheckCircle2 className="mt-1 h-5 w-5 flex-shrink-0 text-cyan-800" />
                <p className="text-sm font-bold leading-7 text-slate-700">{item}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          {whyUs.map((item) => (
            <div key={item.title} className="card p-7">
              <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-900/10 text-cyan-900">
                <item.icon className="h-7 w-7" />
              </div>
              <h3 className="text-xl font-extrabold text-slate-950">{item.title}</h3>
              <p className="mt-3 text-sm leading-7 text-slate-600">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="services" className="bg-white/60 py-20 sm:py-24">
      <div className="section-container">
        <SectionHeading
          eyebrow="خدماتنا"
          title="خدمات واضحة بدون باقات وهمية أو وعود غير موثقة"
          subtitle="تم إعادة صياغة الخدمات لتناسب شركة تحصيل ديون حقيقية، مع التركيز على الدراسة، المتابعة، التسوية، والتقارير."
        />
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <article key={service.title} className="card p-7">
              <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-900 text-white">
                <service.icon className="h-7 w-7" />
              </div>
              <h3 className="text-xl font-extrabold text-slate-950">{service.title}</h3>
              <p className="mt-3 text-sm leading-7 text-slate-600">{service.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Process() {
  return (
    <section id="process" className="py-20 sm:py-24">
      <div className="section-container">
        <SectionHeading
          eyebrow="آلية العمل"
          title="رحلة واضحة من استقبال الطلب إلى التقرير النهائي"
          subtitle="الزائر يحتاج أن يفهم كيف ستتعامل الشركة مع ملفه قبل أن يرسل بيانات حساسة. لذلك تم تبسيط المسار إلى خطوات عملية ومطمئنة."
        />
        <div className="relative grid gap-5 lg:grid-cols-5">
          {processSteps.map((step) => (
            <div key={step.number} className="card relative p-6">
              <div className="mb-5 inline-flex rounded-2xl bg-slate-950 px-4 py-2 text-lg font-extrabold text-white">{step.number}</div>
              <h3 className="text-lg font-extrabold text-slate-950">{step.title}</h3>
              <p className="mt-3 text-sm leading-7 text-slate-600">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Sectors() {
  return (
    <section className="bg-slate-950 py-20 text-white sm:py-24">
      <div className="section-container grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
        <div>
          <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-bold text-cyan-100">
            <Users className="h-4 w-4" />
            القطاعات التي نخدمها
          </span>
          <h2 className="text-3xl font-extrabold leading-tight sm:text-4xl">موقع يخاطب الشركات التي لديها مستحقات متأخرة.</h2>
          <p className="mt-5 text-base leading-8 text-slate-300">
            إضافة هذا القسم تجعل الزائر يعرف سريعًا إن كانت الخدمة مناسبة له، وتزيد ثقة أصحاب الشركات والمؤسسات بأن الموقع يفهم طبيعة أعمالهم.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {sectors.map((sector) => (
            <div key={sector} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
              <CheckCircle2 className="h-5 w-5 flex-shrink-0 text-cyan-300" />
              <span className="font-bold text-slate-100">{sector}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Compliance() {
  return (
    <section id="compliance" className="py-20 sm:py-24">
      <div className="section-container">
        <SectionHeading
          eyebrow="السرية والامتثال"
          title="الثقة أهم من كثرة المؤثرات البصرية"
          subtitle="لذلك تم حذف الادعاءات غير الموثقة عن التراخيص والشركاء والأرقام، واستبدالها برسائل مهنية آمنة يمكن تعديلها بعد استلام بيانات العميل الرسمية."
        />
        <div className="grid gap-5 md:grid-cols-3">
          {compliance.map((item) => (
            <article key={item.title} className="card p-8 text-center">
              <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-cyan-900/10 text-cyan-900">
                <item.icon className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-extrabold text-slate-950">{item.title}</h3>
              <p className="mt-3 text-sm leading-7 text-slate-600">{item.description}</p>
            </article>
          ))}
        </div>
        <div className="mt-8 rounded-3xl border border-amber-200 bg-amber-50 p-6 text-sm leading-8 text-amber-950">
          <strong>ملاحظة مهمة:</strong> لا تذكر أي ترخيص، اعتماد، شريك، نسبة نجاح، أو مبلغ تم تحصيله إلا بعد أن يزودك العميل بمعلومة رسمية موثقة. هذا يحميك ويحمي العميل من الادعاءات غير الدقيقة.
        </div>
      </div>
    </section>
  );
}

function Faq() {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <section id="faq" className="bg-white/60 py-20 sm:py-24">
      <div className="section-container">
        <SectionHeading
          eyebrow="الأسئلة الشائعة"
          title="إجابات مختصرة تزيل تردد الزائر"
          subtitle="تمت صياغة الأسئلة لتناسب موقعًا تعريفيًا فقط، بدون وعد بنتائج أو أسعار ثابتة."
        />
        <div className="mx-auto max-w-4xl space-y-4">
          {faqItems.map((item, index) => {
            const isOpen = openIndex === index;
            return (
              <div key={item.question} className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
                <button
                  type="button"
                  onClick={() => setOpenIndex(isOpen ? -1 : index)}
                  className="flex w-full items-center justify-between gap-4 p-6 text-right"
                  aria-expanded={isOpen}
                >
                  <span className="text-lg font-extrabold text-slate-950">{item.question}</span>
                  <ChevronDown className={`h-5 w-5 flex-shrink-0 text-cyan-900 transition ${isOpen ? 'rotate-180' : ''}`} />
                </button>
                {isOpen ? <p className="border-t border-slate-100 px-6 pb-6 pt-4 text-sm leading-8 text-slate-600">{item.answer}</p> : null}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  const [sentMessage, setSentMessage] = useState('');

  const mailtoHref = useMemo(() => {
    const subject = encodeURIComponent('طلب استشارة في تحصيل المطالبات المالية');
    return `mailto:${company.email}?subject=${subject}`;
  }, []);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = String(form.get('name') || '').trim();
    const organization = String(form.get('organization') || '').trim();
    const phone = String(form.get('phone') || '').trim();
    const email = String(form.get('email') || '').trim();
    const claimType = String(form.get('claimType') || '').trim();
    const message = String(form.get('message') || '').trim();

    const body = [
      'طلب استشارة من موقع الشركة',
      `الاسم: ${name}`,
      `الشركة: ${organization}`,
      `رقم الجوال: ${phone}`,
      `البريد: ${email}`,
      `نوع المطالبة: ${claimType}`,
      `الرسالة: ${message}`,
    ].join('\n');

    const whatsappUrl = `https://wa.me/${company.phoneLink}?text=${encodeURIComponent(body)}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    setSentMessage('تم تجهيز رسالتك وفتح واتساب لإرسالها. اربط رقم الشركة الحقيقي قبل تسليم الموقع للعميل.');
    event.currentTarget.reset();
  }

  return (
    <section id="contact" className="py-20 sm:py-24">
      <div className="section-container grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
        <div>
          <span className="section-eyebrow">
            <Mail className="h-4 w-4" />
            تواصل معنا
          </span>
          <h2 className="section-title">اجعل خطوة التواصل واضحة وسهلة من أي مكان في الموقع.</h2>
          <p className="section-subtitle text-right">
            النموذج لا يعطي رسالة نجاح وهمية؛ بل يفتح واتساب برسالة جاهزة تحتوي بيانات الزائر. يمكنك لاحقًا ربطه ببريد رسمي أو Backend حسب طلب العميل.
          </p>

          <div className="mt-8 space-y-4">
            <a href={`tel:${company.phoneLink}`} className="flex items-center gap-4 rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-cyan-800">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-900/10 text-cyan-900">
                <Phone className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-500">الهاتف</p>
                <p className="font-extrabold text-slate-950">{company.phoneDisplay}</p>
              </div>
            </a>
            <a href={mailtoHref} className="flex items-center gap-4 rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-cyan-800">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-900/10 text-cyan-900">
                <Mail className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-500">البريد الإلكتروني</p>
                <p className="font-extrabold text-slate-950">{company.email}</p>
              </div>
            </a>
            <div className="flex items-center gap-4 rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-900/10 text-cyan-900">
                <MapPin className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-500">الموقع وساعات العمل</p>
                <p className="font-extrabold text-slate-950">{company.location}</p>
                <p className="mt-1 text-sm text-slate-500">{company.workingHours}</p>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="card p-6 sm:p-8">
          <div className="grid gap-5 sm:grid-cols-2">
            <label className="grid gap-2 text-sm font-bold text-slate-700">
              الاسم الكامل
              <input className="input-field" name="name" placeholder="اكتب اسمك" required />
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">
              اسم الشركة
              <input className="input-field" name="organization" placeholder="اسم الشركة أو المؤسسة" required />
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">
              رقم الجوال
              <input className="input-field" name="phone" placeholder="05xxxxxxxx" inputMode="tel" required />
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">
              البريد الإلكتروني
              <input className="input-field" name="email" placeholder="name@example.com" type="email" />
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700 sm:col-span-2">
              نوع المطالبة
              <select className="input-field" name="claimType" defaultValue="" required>
                <option value="" disabled>
                  اختر نوع المطالبة
                </option>
                <option>مطالبات تجارية</option>
                <option>فواتير متأخرة</option>
                <option>عقود أو توريد</option>
                <option>حالات متعددة تحتاج دراسة</option>
                <option>استفسار عام</option>
              </select>
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700 sm:col-span-2">
              الرسالة
              <textarea className="input-field min-h-36 resize-y" name="message" placeholder="اكتب ملخصًا مختصرًا عن طلبك دون إرسال بيانات حساسة جدًا من النموذج العام" required />
            </label>
          </div>
          <button type="submit" className="primary-button mt-6 w-full">
            <MessageCircle className="h-5 w-5" />
            إرسال الطلب عبر واتساب
          </button>
          {sentMessage ? <p className="mt-4 rounded-2xl bg-cyan-50 p-4 text-sm font-bold leading-7 text-cyan-900">{sentMessage}</p> : null}
          <p className="mt-4 text-center text-xs leading-6 text-slate-500">
            بإرسال الطلب أنت توافق على استخدام بياناتك لغرض التواصل والرد على الاستفسار فقط.
          </p>
        </form>
      </div>
    </section>
  );
}

function Legal() {
  return (
    <section id="legal" className="bg-slate-100 py-16">
      <div className="section-container grid gap-5 lg:grid-cols-2">
        <div className="rounded-3xl bg-white p-7 shadow-sm">
          <h3 className="text-xl font-extrabold text-slate-950">سياسة الخصوصية المختصرة</h3>
          <p className="mt-3 text-sm leading-8 text-slate-600">
            يتم استخدام بيانات نموذج التواصل للرد على طلبات العملاء فقط. لا يتم بيع البيانات أو مشاركتها مع أطراف خارجية إلا عند الحاجة لتقديم الخدمة وبموافقة صاحب العلاقة أو وفق ما تتطلبه الأنظمة. يجب استبدال هذا النص بسياسة خصوصية كاملة عند إطلاق الموقع رسميًا.
          </p>
        </div>
        <div className="rounded-3xl bg-white p-7 shadow-sm">
          <h3 className="text-xl font-extrabold text-slate-950">شروط الاستخدام المختصرة</h3>
          <p className="mt-3 text-sm leading-8 text-slate-600">
            المعلومات المنشورة في الموقع تعريفية ولا تعد وعدًا بنتيجة تحصيل محددة أو استشارة قانونية مستقلة. يتم تقييم كل مطالبة حسب مستنداتها وظروفها، وتحدد الرسوم والإجراءات بعد دراسة الحالة وموافقة العميل.
          </p>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-slate-950 py-10 text-white">
      <div className="section-container flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-cyan-600 text-lg font-extrabold">ش</div>
            <div>
              <p className="font-extrabold">{company.name}</p>
              <p className="text-sm text-slate-400">{company.slogan}</p>
            </div>
          </div>
          <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-400">
            موقع تعريفي احترافي لشركة تحصيل ديون، مصمم للثقة والوضوح وسهولة التواصل مع الحفاظ على الطابع الرسمي للمجال.
          </p>
        </div>
        <div className="flex flex-wrap gap-3 text-sm font-bold text-slate-300">
          <a href="#legal" className="hover:text-white">الخصوصية</a>
          <span className="text-slate-600">/</span>
          <a href="#legal" className="hover:text-white">الشروط</a>
          <span className="text-slate-600">/</span>
          <a href="#contact" className="hover:text-white">تواصل معنا</a>
        </div>
      </div>
    </footer>
  );
}

function FloatingActions() {
  const message = encodeURIComponent('مرحبًا، أريد الاستفسار عن خدمات تحصيل المطالبات المالية.');
  return (
    <div className="fixed bottom-5 left-5 z-40 flex flex-col gap-3">
      <a
        href={`https://wa.me/${company.phoneLink}?text=${message}`}
        target="_blank"
        rel="noreferrer"
        className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-600 text-white shadow-xl shadow-emerald-900/20 transition hover:scale-105"
        aria-label="واتساب"
      >
        <MessageCircle className="h-6 w-6" />
      </a>
      <a
        href={`tel:${company.phoneLink}`}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-950 text-white shadow-xl shadow-slate-900/20 transition hover:scale-105"
        aria-label="اتصال"
      >
        <Phone className="h-6 w-6" />
      </a>
    </div>
  );
}

export default function App() {
  return (
    <main>
      <Navigation />
      <Hero />
      <TrustStrip />
      <About />
      <Services />
      <Process />
      <Sectors />
      <Compliance />
      <Faq />
      <Contact />
      <Legal />
      <Footer />
      <FloatingActions />
    </main>
  );
}
