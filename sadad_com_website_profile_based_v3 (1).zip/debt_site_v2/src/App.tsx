import type { FormEvent, ReactNode } from 'react';
import { useEffect, useMemo, useRef, useState } from 'react';
import type { LucideIcon } from 'lucide-react';
import {
  ArrowLeft,
  Banknote,
  BarChart3,
  BriefcaseBusiness,
  Building2,
  CheckCircle2,
  ChevronDown,
  ClipboardCheck,
  Clock3,
  Cpu,
  Eye,
  Factory,
  FileCheck2,
  FileText,
  Handshake,
  HeartPulse,
  Home,
  Landmark,
  Lightbulb,
  ListChecks,
  LockKeyhole,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  Send,
  ShieldCheck,
  Sparkles,
  Store,
  Target,
  Truck,
  Users,
  X,
} from 'lucide-react';

type RouteKey = 'home' | 'about' | 'services' | 'process' | 'sectors' | 'faq' | 'contact' | 'privacy' | 'terms';

type CardItem = {
  icon: LucideIcon;
  title: string;
  description: string;
};

type ServiceItem = CardItem & {
  points: string[];
};

type FaqItem = {
  question: string;
  answer: string;
};

const company = {
  name: 'سداد كوم المحدودة',
  enName: 'SADAD COM LIMITED',
  slogan: 'حلول احترافية متكاملة بجودة عالية',
  shortSlogan: 'تحصيل، تشغيل، متابعة، وحلول أعمال',
  phoneDisplay: '0545372137',
  phoneLink: '966545372137',
  email: 'sdadcomo@gmail.com',
  location: 'المملكة العربية السعودية',
  workingHours: 'يتم استقبال طلبات التواصل والرد عليها خلال أوقات العمل الرسمية',
};

const navLinks: { label: string; route: RouteKey; icon: LucideIcon }[] = [
  { label: 'الرئيسية', route: 'home', icon: Home },
  { label: 'من نحن', route: 'about', icon: Building2 },
  { label: 'خدماتنا', route: 'services', icon: BriefcaseBusiness },
  { label: 'آلية العمل', route: 'process', icon: ListChecks },
  { label: 'قطاعات العمل', route: 'sectors', icon: Landmark },
  { label: 'الأسئلة الشائعة', route: 'faq', icon: FileCheck2 },
  { label: 'تواصل معنا', route: 'contact', icon: Mail },
];

const services: ServiceItem[] = [
  {
    icon: Banknote,
    title: 'تحصيل الديون وإدارة المطالبات',
    description:
      'متابعة ملفات المديونيات والمطالبات المالية من مرحلة الاستلام والفرز حتى التواصل والتسوية والتوصية بالمسار المناسب.',
    points: ['استلام ملفات المديونيات', 'فرز وتصنيف المطالبات', 'متابعة السداد والتسوية'],
  },
  {
    icon: ClipboardCheck,
    title: 'الحلول والخدمات المتكاملة',
    description:
      'حلول احترافية تساعد العملاء على تحسين كفاءة الأعمال وتطوير إجراءات المتابعة والرقابة التشغيلية.',
    points: ['تحليل الاحتياج التشغيلي', 'بناء مسارات متابعة واضحة', 'تحسين جودة الأداء'],
  },
  {
    icon: Users,
    title: 'خدمات الدعم والتشغيل',
    description:
      'تشغيل ومساندة الأعمال اليومية من خلال فرق عمل مؤهلة وإجراءات متابعة تضمن انتظام العمل ووضوح المسؤوليات.',
    points: ['دعم العمليات اليومية', 'تنظيم فرق العمل', 'رفع كفاءة التشغيل'],
  },
  {
    icon: Lightbulb,
    title: 'الاستشارات والتطوير',
    description:
      'مساندة العملاء في تطوير أساليب العمل ورفع كفاءة الأداء من خلال حلول عملية قابلة للتطبيق.',
    points: ['مراجعة الإجراءات الحالية', 'اقتراح حلول تطويرية', 'دعم قرارات التحسين'],
  },
  {
    icon: BriefcaseBusiness,
    title: 'إدارة وتنفيذ المشاريع',
    description:
      'تنفيذ المشاريع التشغيلية والإدارية وفق خطط مدروسة ومراحل واضحة تساعد على ضبط النتائج والمتابعة.',
    points: ['تحديد نطاق المشروع', 'تنفيذ ومتابعة المراحل', 'إدارة الجودة والنتائج'],
  },
  {
    icon: FileText,
    title: 'خدمات المتابعة والصيانة',
    description:
      'متابعة مستمرة للأعمال والحلول المعتمدة لضمان جودة التنفيذ ومعالجة الملاحظات بشكل منظم.',
    points: ['متابعة الأداء', 'رصد الملاحظات', 'تحسين مستمر للخدمة'],
  },
];

const processSteps = [
  {
    number: '01',
    title: 'دراسة واستلام بيانات العميل',
    description: 'استقبال الطلب الأولي وفهم طبيعة العميل ونوع الملفات أو المطالبات المطلوب العمل عليها.',
  },
  {
    number: '02',
    title: 'إعداد الحلول المناسبة',
    description: 'تحليل الحالة وتحديد أفضل مسار للعمل بما يتوافق مع طبيعة المديونيات أو الخدمة التشغيلية المطلوبة.',
  },
  {
    number: '03',
    title: 'التخطيط والتنفيذ',
    description: 'وضع خطة واضحة للمتابعة، وتحديد الأولويات والمسؤوليات ومراحل التنفيذ.',
  },
  {
    number: '04',
    title: 'المتابعة وضمان الجودة',
    description: 'متابعة الإجراءات المنفذة وقياس جودة الأداء والتحقق من سلامة مسار العمل.',
  },
  {
    number: '05',
    title: 'التسليم النهائي والدعم المستمر',
    description: 'تقديم النتائج أو التقارير النهائية مع استمرار الدعم والمتابعة عند الحاجة.',
  },
];

const collectionMechanism = [
  {
    number: '01',
    title: 'استلام ملف المديونيات',
    description: 'استقبال بيانات الملفات والمطالبات المالية من العميل بطريقة منظمة وواضحة.',
  },
  {
    number: '02',
    title: 'فرز وتصنيف الملفات',
    description: 'تصنيف الحالات بحسب نوع الدين، قيمته، عمر المطالبة، والبيانات المتوفرة.',
  },
  {
    number: '03',
    title: 'إسناد الملفات للفريق المناسب',
    description: 'توزيع الملفات على المختصين بحسب طبيعة كل حالة وخطة المتابعة المعتمدة.',
  },
  {
    number: '04',
    title: 'تحديث البيانات',
    description: 'مراجعة البيانات المتاحة وتحديثها قبل بدء التواصل لضمان دقة المتابعة.',
  },
  {
    number: '05',
    title: 'التواصل مع العملاء',
    description: 'التواصل عبر القنوات المناسبة مثل الاتصال والرسائل، مع توضيح المطالبة بطريقة رسمية.',
  },
  {
    number: '06',
    title: 'معالجة أسباب التعثر',
    description: 'فهم أسباب عدم السداد والعمل على حلول مناسبة مثل الجدولة أو التسوية عند الإمكان.',
  },
  {
    number: '07',
    title: 'تقييم المسار النظامي',
    description: 'تحديد الحالات التي قد تحتاج إلى توصية بإجراء نظامي وفق طبيعة الملف ومستنداته.',
  },
  {
    number: '08',
    title: 'مراقبة الجودة',
    description: 'متابعة جودة التواصل والإجراءات والنتائج لضمان الالتزام بالمعايير المهنية.',
  },
  {
    number: '09',
    title: 'التصعيد عند الحاجة',
    description: 'اقتراح الإجراءات المناسبة للحالات التي لم تستجب للمسارات الودية أو التشغيلية المعتادة.',
  },
];

const sectors: CardItem[] = [
  {
    icon: Landmark,
    title: 'الجهات الحكومية',
    description: 'حلول متابعة ودعم للجهات التي تحتاج إلى تنظيم المطالبات أو الخدمات المساندة.',
  },
  {
    icon: Building2,
    title: 'الهيئات والقطاعات شبه الحكومية',
    description: 'خدمات تشغيل ومتابعة مناسبة للجهات ذات الإجراءات المنظمة ومتطلبات الجودة العالية.',
  },
  {
    icon: Banknote,
    title: 'الجهات المصرفية والمالية والتأمين',
    description: 'متابعة مطالبات وملفات ذات طبيعة مالية تتطلب دقة وسرية وانضباطًا في الإجراءات.',
  },
  {
    icon: Handshake,
    title: 'القطاع غير الربحي والجمعيات',
    description: 'مساندة الجهات غير الربحية في أعمال المتابعة والتشغيل وإدارة المستحقات عند الحاجة.',
  },
  {
    icon: Factory,
    title: 'الجهات الصناعية',
    description: 'دعم المنشآت الصناعية في متابعة الالتزامات والمطالبات المرتبطة بالتوريد والتشغيل.',
  },
  {
    icon: Store,
    title: 'جهات التجزئة',
    description: 'متابعة فواتير ومستحقات وعمليات تشغيلية متكررة تحتاج إلى تنظيم واضح.',
  },
  {
    icon: HeartPulse,
    title: 'الجهات الصحية',
    description: 'حلول متابعة مهنية تراعي حساسية القطاع الصحي ومتطلبات التعامل مع البيانات.',
  },
  {
    icon: Cpu,
    title: 'الاتصالات وتقنية المعلومات',
    description: 'خدمات مناسبة لمحافظ الاتصالات، الفواتير، عقود الخدمات، وملفات التشغيل التقني.',
  },
  {
    icon: Truck,
    title: 'القطاعات اللوجستية',
    description: 'مساندة شركات النقل والخدمات اللوجستية في متابعة المطالبات والتزامات العملاء.',
  },
];

const values: CardItem[] = [
  {
    icon: ShieldCheck,
    title: 'الجودة',
    description: 'الالتزام بمعايير عالية في تقديم الأعمال والنتائج، مع مراجعة مستمرة لمستوى الخدمة.',
  },
  {
    icon: Users,
    title: 'الاحترافية',
    description: 'العمل بفريق مؤهل ومنهج واضح يضمن الجدية والكفاءة في تنفيذ المهام.',
  },
  {
    icon: Eye,
    title: 'الشفافية',
    description: 'توضيح الإجراءات والنتائج للعميل ومشاركة المعلومات اللازمة لاتخاذ القرار.',
  },
  {
    icon: Clock3,
    title: 'الالتزام',
    description: 'تنفيذ الأعمال وفق جداول وآليات متابعة محددة تساعد على ضبط الوقت والجودة.',
  },
  {
    icon: Lightbulb,
    title: 'الابتكار',
    description: 'البحث عن حلول حديثة تساعد العملاء على تطوير أعمالهم وتحسين النتائج.',
  },
  {
    icon: Handshake,
    title: 'رضا العملاء',
    description: 'بناء علاقة طويلة المدى مع العملاء من خلال وضوح التعامل وجودة المخرجات.',
  },
];

const whyUs: CardItem[] = [
  {
    icon: Users,
    title: 'خبرة وكفاءة',
    description: 'فريق متخصص يمتلك خبرات عملية في المتابعة والتشغيل وخدمات معالجة المديونيات.',
  },
  {
    icon: ShieldCheck,
    title: 'جودة عالية',
    description: 'تنفيذ الخدمات وفق معايير واضحة تضمن الدقة والالتزام في كل مرحلة.',
  },
  {
    icon: Clock3,
    title: 'سرعة في التنفيذ',
    description: 'تنظيم العمل وتحديد الأولويات يساعدان على تسريع المتابعة دون الإخلال بالجودة.',
  },
  {
    icon: Lightbulb,
    title: 'حلول مبتكرة',
    description: 'تقديم حلول مناسبة حسب طبيعة العميل والسوق بدل الاعتماد على أسلوب واحد لكل الحالات.',
  },
];

const capabilities: CardItem[] = [
  {
    icon: Users,
    title: 'القوة البشرية',
    description:
      'متخصصون في معالجة الديون والخدمات المساندة وفق الأنظمة المتبعة في المملكة العربية السعودية، مع فهم لطبيعة القطاعات المختلفة.',
  },
  {
    icon: Cpu,
    title: 'القوة التكنولوجية',
    description:
      'استخدام أنظمة داخلية لمتابعة وإدارة ملفات التحصيل والخدمات التشغيلية، مع تنظيم البيانات وربط مراحل العمل بطريقة واضحة.',
  },
];

const goals: CardItem[] = [
  {
    icon: ShieldCheck,
    title: 'تقديم خدمات احترافية عالية الجودة',
    description: 'رفع مستوى جودة الخدمات المقدمة للعملاء من خلال منهج عمل واضح ومتابعة مستمرة.',
  },
  {
    icon: BarChart3,
    title: 'توسيع نطاق الأعمال والخدمات',
    description: 'تطوير نطاق الخدمات لتلبية احتياجات قطاعات متنوعة في السوق.',
  },
  {
    icon: Handshake,
    title: 'بناء شراكات استراتيجية ناجحة',
    description: 'العمل على علاقات طويلة المدى مبنية على الثقة والنتائج المهنية.',
  },
  {
    icon: Cpu,
    title: 'مواكبة التقنيات والحلول الحديثة',
    description: 'تطوير أساليب العمل بما يتناسب مع متطلبات السوق والتحول التشغيلي.',
  },
];

const faqItems: FaqItem[] = [
  {
    question: 'ما طبيعة عمل سداد كوم المحدودة؟',
    answer:
      'تقدم الشركة حلولًا احترافية في تحصيل الديون وإدارة المطالبات، إضافة إلى خدمات الدعم والتشغيل والاستشارات وإدارة المشاريع والمتابعة.',
  },
  {
    question: 'هل تقتصر الخدمات على تحصيل الديون فقط؟',
    answer:
      'لا، التحصيل جزء أساسي من الخدمات، لكن الشركة تقدم أيضًا حلولًا تشغيلية واستشارية وخدمات متابعة وصيانة وإدارة مشاريع حسب احتياج العميل.',
  },
  {
    question: 'ما القطاعات التي تخدمها الشركة؟',
    answer:
      'تخدم الشركة قطاعات متعددة مثل الجهات الحكومية وشبه الحكومية، الجهات المصرفية والمالية والتأمين، الاتصالات وتقنية المعلومات، الصحة، التجزئة، الصناعة، واللوجستيات.',
  },
  {
    question: 'كيف تتم متابعة ملفات المديونيات؟',
    answer:
      'تبدأ العملية باستلام الملفات وفرزها وتصنيفها، ثم إسنادها للفريق المناسب، وتحديث البيانات، والتواصل، ومعالجة أسباب التعثر، ومراقبة الجودة والتوصية بالإجراء المناسب عند الحاجة.',
  },
  {
    question: 'هل يتم التعامل مع البيانات بسرية؟',
    answer:
      'نعم، يتم التعامل مع بيانات العملاء والملفات باعتبارها معلومات حساسة، ويتم استخدامها في نطاق الخدمة المتفق عليها فقط.',
  },
  {
    question: 'كيف أبدأ التعاون مع الشركة؟',
    answer:
      'يمكنك التواصل عبر الهاتف أو البريد أو نموذج الموقع، ثم يتم فهم احتياجك وتحديد المعلومات المطلوبة واقتراح المسار الأنسب.',
  },
];

const routeLabels: Record<RouteKey, string> = {
  home: 'الرئيسية',
  about: 'من نحن',
  services: 'خدماتنا',
  process: 'آلية العمل',
  sectors: 'قطاعات العمل',
  faq: 'الأسئلة الشائعة',
  contact: 'تواصل معنا',
  privacy: 'سياسة الخصوصية',
  terms: 'شروط الاستخدام',
};

function hrefFor(route: RouteKey) {
  return route === 'home' ? '#/' : `#/${route}`;
}

function getRouteFromHash(): RouteKey {
  const value = window.location.hash.replace(/^#\/?/, '') || 'home';
  const routes: RouteKey[] = ['home', 'about', 'services', 'process', 'sectors', 'faq', 'contact', 'privacy', 'terms'];
  return routes.includes(value as RouteKey) ? (value as RouteKey) : 'home';
}

function useRoute() {
  const [route, setRoute] = useState<RouteKey>(() => getRouteFromHash());

  useEffect(() => {
    const onHashChange = () => setRoute(getRouteFromHash());
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    document.title = `${routeLabels[route]} | ${company.name}`;
  }, [route]);

  return route;
}

function Reveal({ children, className = '', delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(() =>
    typeof window !== 'undefined' ? window.matchMedia('(prefers-reduced-motion: reduce)').matches : false,
  );

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;

    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.15, rootMargin: '0px 0px -8% 0px' },
    );

    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className={`reveal ${visible ? 'is-visible' : ''} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex min-w-0 items-center gap-3">
      <div
        className={`${compact ? 'h-11 w-11 text-xl' : 'h-12 w-12 text-2xl'} brand-mark flex flex-shrink-0 items-center justify-center rounded-2xl font-black text-white shadow-lg shadow-purple-950/25`}
      >
        S
      </div>
      <div className="min-w-0">
        <p className="truncate text-lg font-extrabold text-slate-950">{company.name}</p>
        <p className="hidden text-xs font-semibold tracking-wide text-slate-500 sm:block">{company.enName}</p>
      </div>
    </div>
  );
}

function SectionHeading({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle: string }) {
  return (
    <Reveal className="mx-auto mb-12 max-w-3xl text-center">
      <span className="section-eyebrow">
        <Sparkles className="h-4 w-4" />
        {eyebrow}
      </span>
      <h2 className="section-title">{title}</h2>
      <p className="section-subtitle">{subtitle}</p>
    </Reveal>
  );
}

function PageHero({ eyebrow, title, subtitle, icon: Icon }: { eyebrow: string; title: string; subtitle: string; icon: LucideIcon }) {
  return (
    <section className="relative overflow-hidden bg-slate-950 py-16 text-white sm:py-20 lg:py-24">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(124,58,237,0.34),transparent_34%),radial-gradient(circle_at_bottom_left,rgba(255,255,255,0.08),transparent_30%)]" />
      <div className="section-container relative">
        <Reveal className="max-w-4xl">
          <span className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-bold text-purple-100">
            <Icon className="h-4 w-4" />
            {eyebrow}
          </span>
          <h1 className="text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl lg:text-6xl">{title}</h1>
          <p className="mt-6 max-w-3xl text-base leading-8 text-slate-300 sm:text-lg">{subtitle}</p>
        </Reveal>
      </div>
    </section>
  );
}

function RouteLink({
  route,
  children,
  className = '',
  onClick,
  ariaLabel,
}: {
  route: RouteKey;
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  ariaLabel?: string;
}) {
  return (
    <a href={hrefFor(route)} className={className} onClick={onClick} aria-label={ariaLabel}>
      {children}
    </a>
  );
}

function ContactButtons({ compact = false }: { compact?: boolean }) {
  const message = encodeURIComponent('مرحبًا، أود الاستفسار عن خدمات سداد كوم المحدودة.');
  return (
    <div className={`flex flex-col gap-3 sm:flex-row ${compact ? 'sm:justify-start' : 'justify-center'}`}>
      <a className="primary-button" href={`https://wa.me/${company.phoneLink}?text=${message}`} target="_blank" rel="noreferrer">
        <MessageCircle className="h-5 w-5" />
        تواصل عبر واتساب
      </a>
      <RouteLink route="contact" className="secondary-button">
        <Mail className="h-5 w-5" />
        اطلب استشارة
      </RouteLink>
    </div>
  );
}

function Navigation({ activeRoute }: { activeRoute: RouteKey }) {
  const [isOpen, setIsOpen] = useState(false);
  const closeMenu = () => setIsOpen(false);

  return (
    <header className="sticky top-0 z-50 animate-nav border-b border-white/50 bg-white/92 backdrop-blur-xl">
      <div className="section-container flex h-20 items-center justify-between">
        <RouteLink route="home" onClick={closeMenu} className="flex min-w-0 items-center gap-3" ariaLabel="الانتقال للرئيسية">
          <BrandMark />
        </RouteLink>

        <nav className="hidden items-center gap-1 xl:flex" aria-label="روابط الموقع">
          {navLinks.map((link) => {
            const isActive = activeRoute === link.route;
            return (
              <RouteLink
                key={link.route}
                route={link.route}
                className={`rounded-full px-4 py-2 text-sm font-bold transition ${
                  isActive ? 'bg-purple-900 text-white shadow-sm' : 'text-slate-600 hover:bg-purple-50 hover:text-purple-900'
                }`}
              >
                {link.label}
              </RouteLink>
            );
          })}
        </nav>

        <div className="hidden xl:block">
          <RouteLink route="contact" className="primary-button">
            اطلب استشارة
            <ArrowLeft className="h-4 w-4" />
          </RouteLink>
        </div>

        <button
          type="button"
          onClick={() => setIsOpen((current) => !current)}
          className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-800 xl:hidden"
          aria-label="فتح القائمة"
          aria-expanded={isOpen}
        >
          {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {isOpen ? (
        <div className="mobile-menu border-t border-slate-100 bg-white xl:hidden">
          <div className="section-container grid gap-2 py-4">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = activeRoute === link.route;
              return (
                <RouteLink
                  key={link.route}
                  route={link.route}
                  onClick={closeMenu}
                  className={`flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-bold transition ${
                    isActive ? 'bg-purple-900 text-white' : 'text-slate-700 hover:bg-purple-50 hover:text-purple-900'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {link.label}
                </RouteLink>
              );
            })}
          </div>
        </div>
      ) : null}
    </header>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden py-16 sm:py-20 lg:py-24">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top_right,rgba(124,58,237,0.18),transparent_35%),radial-gradient(circle_at_bottom_left,rgba(30,27,75,0.10),transparent_30%)]" />
      <div className="section-container grid items-center gap-12 lg:grid-cols-[1.08fr_0.92fr]">
        <div>
          <Reveal>
            <span className="section-eyebrow">
              <ShieldCheck className="h-4 w-4" />
              {company.name} — {company.shortSlogan}
            </span>
          </Reveal>
          <Reveal delay={90}>
            <h1 className="max-w-4xl text-4xl font-extrabold leading-[1.24] tracking-tight text-slate-950 sm:text-5xl lg:text-6xl">
              حلول متكاملة لتحصيل الديون وتشغيل الأعمال بجودة واحترافية.
            </h1>
          </Reveal>
          <Reveal delay={160}>
            <p className="mt-6 max-w-2xl text-lg leading-9 text-slate-600">
              تقدم سداد كوم المحدودة خدمات احترافية متكاملة لمحافظ الاتصالات والمرافق والبنوك والتأمين، مع حلول دعم وتشغيل واستشارات وإدارة مشاريع تساعد العملاء على رفع جودة الأداء وبناء شراكات طويلة المدى.
            </p>
          </Reveal>

          <Reveal delay={230} className="mt-8">
            <ContactButtons compact />
          </Reveal>

          <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:max-w-2xl">
            {['فريق متخصص', 'جودة واحترافية', 'حلول مبتكرة', 'ثقة وشراكات'].map((item, index) => (
              <Reveal key={item} delay={280 + index * 80}>
                <div className="flex items-center gap-3 rounded-2xl border border-white/70 bg-white/80 p-4 shadow-sm backdrop-blur">
                  <CheckCircle2 className="h-5 w-5 flex-shrink-0 text-purple-800" />
                  <span className="text-sm font-bold text-slate-700">{item}</span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>

        <Reveal delay={140} className="relative">
          <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-purple-700/15 blur-3xl" />
          <div className="absolute -bottom-8 -left-8 h-48 w-48 rounded-full bg-indigo-950/15 blur-3xl" />
          <div className="relative overflow-hidden rounded-[2rem] border border-white/80 bg-white p-3 shadow-2xl shadow-purple-950/10">
            <img src="./images/team.jpg" alt="بيئة عمل احترافية" className="h-[320px] w-full rounded-[1.5rem] object-cover sm:h-[420px]" />
            <div className="absolute bottom-7 right-7 left-7 rounded-3xl border border-white/50 bg-white/90 p-5 shadow-xl backdrop-blur">
              <p className="text-xs font-bold text-purple-800">SADAD COM LIMITED</p>
              <p className="mt-2 text-lg font-extrabold text-slate-950">نحو مستقبل أكثر تطورًا وابتكارًا.</p>
              <p className="mt-2 text-sm leading-7 text-slate-600">خدمات مبنية على الجودة، التقنية، والكفاءة المهنية.</p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function TrustStrip() {
  const items = [
    { icon: Target, label: 'رؤية واضحة' },
    { icon: ShieldCheck, label: 'جودة عالية' },
    { icon: Lightbulb, label: 'ابتكار مستمر' },
    { icon: Handshake, label: 'شراكات استراتيجية' },
    { icon: BarChart3, label: 'نمو مستدام' },
  ];

  return (
    <section className="border-y border-slate-200 bg-white/50 py-6">
      <div className="section-container grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {items.map((item, index) => (
          <Reveal key={item.label} delay={index * 60}>
            <div className="flex items-center justify-center gap-3 rounded-2xl bg-white p-4 shadow-sm">
              <item.icon className="h-5 w-5 text-purple-800" />
              <span className="text-sm font-extrabold text-slate-700">{item.label}</span>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function PreviewAbout() {
  return (
    <section className="py-20 sm:py-24">
      <div className="section-container grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2rem] border border-white bg-white p-3 shadow-2xl shadow-purple-950/10">
            <img src="./images/team.jpg" alt="فريق سداد كوم المحدودة" className="h-[360px] w-full rounded-[1.5rem] object-cover sm:h-[480px]" />
          </div>
        </Reveal>
        <div>
          <Reveal>
            <span className="section-eyebrow">
              <Building2 className="h-4 w-4" />
              من نحن
            </span>
            <h2 className="section-title">شركة متخصصة في حلول التحصيل والخدمات المتكاملة.</h2>
            <p className="section-subtitle text-right">
              سداد كوم المحدودة تقدم خدمات احترافية متكاملة بخبرة وجودة عالية، وتركز على تقديم حلول تلائم احتياجات العملاء وتواكب تطورات السوق من خلال الجودة والابتكار والكفاءة.
            </p>
          </Reveal>
          <div className="mt-7 grid gap-4 sm:grid-cols-2">
            {whyUs.map((item, index) => (
              <Reveal key={item.title} delay={index * 80}>
                <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                  <item.icon className="mb-3 h-7 w-7 text-purple-800" />
                  <h3 className="font-extrabold text-slate-950">{item.title}</h3>
                  <p className="mt-2 text-sm leading-7 text-slate-600">{item.description}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-8">
            <RouteLink route="about" className="secondary-button">
              معرفة المزيد عن الشركة
              <ArrowLeft className="h-4 w-4" />
            </RouteLink>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function PreviewServices() {
  return (
    <section className="bg-white/65 py-20 sm:py-24">
      <div className="section-container">
        <SectionHeading
          eyebrow="خدماتنا"
          title="خدمات أوسع من التحصيل التقليدي"
          subtitle="تجمع سداد كوم المحدودة بين تحصيل الديون والحلول التشغيلية والاستشارات وإدارة المشاريع لضمان خدمة متكاملة للعميل."
        />
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {services.slice(0, 6).map((service, index) => (
            <Reveal key={service.title} delay={index * 80}>
              <article className="card h-full p-7">
                <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-purple-900 text-white">
                  <service.icon className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-extrabold text-slate-950">{service.title}</h3>
                <p className="mt-3 text-sm leading-7 text-slate-600">{service.description}</p>
              </article>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-8 text-center">
          <RouteLink route="services" className="primary-button">
            المزيد من الخدمات
            <ArrowLeft className="h-4 w-4" />
          </RouteLink>
        </Reveal>
      </div>
    </section>
  );
}

function PreviewProcess() {
  return (
    <section className="py-20 sm:py-24">
      <div className="section-container">
        <SectionHeading
          eyebrow="آلية العمل"
          title="مسار عمل واضح من الدراسة حتى الدعم المستمر"
          subtitle="تبدأ الخدمة بفهم احتياج العميل، ثم بناء الحل المناسب، وتنفيذه، ومتابعة الجودة حتى الوصول إلى نتيجة واضحة."
        />
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-5">
          {processSteps.map((step, index) => (
            <Reveal key={step.number} delay={index * 90}>
              <div className="card h-full p-6">
                <div className="mb-5 inline-flex rounded-2xl bg-slate-950 px-4 py-2 text-lg font-extrabold text-white">{step.number}</div>
                <h3 className="text-lg font-extrabold text-slate-950">{step.title}</h3>
                <p className="mt-3 text-sm leading-7 text-slate-600">{step.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-8 text-center">
          <RouteLink route="process" className="secondary-button">
            عرض آلية تحصيل الديون
            <ArrowLeft className="h-4 w-4" />
          </RouteLink>
        </Reveal>
      </div>
    </section>
  );
}

function CapabilitiesSection() {
  return (
    <section className="bg-slate-950 py-20 text-white sm:py-24">
      <div className="section-container grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-center">
        <Reveal>
          <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-bold text-purple-100">
            <Cpu className="h-4 w-4" />
            إمكانياتنا
          </span>
          <h2 className="text-3xl font-extrabold leading-tight sm:text-4xl">قوة بشرية متخصصة وقوة تقنية لتنظيم العمل.</h2>
          <p className="mt-5 text-base leading-8 text-slate-300">
            تعتمد سداد كوم المحدودة على مزيج من الخبرة البشرية والأنظمة التقنية لمتابعة وإدارة الملفات والخدمات بطريقة منظمة وآمنة.
          </p>
        </Reveal>
        <div className="grid gap-5 md:grid-cols-2">
          {capabilities.map((item, index) => (
            <Reveal key={item.title} delay={index * 100}>
              <div className="h-full rounded-3xl border border-white/10 bg-white/5 p-7 shadow-lg shadow-black/10">
                <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-purple-900">
                  <item.icon className="h-7 w-7" />
                </div>
                <h3 className="text-2xl font-extrabold">{item.title}</h3>
                <p className="mt-4 text-sm leading-8 text-slate-300">{item.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function SectorsSection() {
  return (
    <section className="py-20 sm:py-24">
      <div className="section-container">
        <SectionHeading
          eyebrow="قطاعات العمل"
          title="نخدم قطاعات متعددة باحتياجات مختلفة"
          subtitle="تمتد خدمات الشركة لتشمل جهات حكومية وشبه حكومية وقطاعات مالية وصناعية وصحية وتقنية ولوجستية."
        />
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {sectors.map((sector, index) => (
            <Reveal key={sector.title} delay={index * 60}>
              <article className="card h-full p-7">
                <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-purple-900/10 text-purple-900">
                  <sector.icon className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-extrabold text-slate-950">{sector.title}</h3>
                <p className="mt-3 text-sm leading-7 text-slate-600">{sector.description}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function CtaSection() {
  return (
    <section className="py-16 sm:py-20">
      <div className="section-container">
        <Reveal>
          <div className="overflow-hidden rounded-[2rem] bg-purple-950 p-8 text-center text-white shadow-2xl shadow-purple-950/20 sm:p-12">
            <p className="text-sm font-bold text-purple-100">ابدأ بخطوة واضحة</p>
            <h2 className="mx-auto mt-3 max-w-3xl text-3xl font-extrabold leading-tight sm:text-4xl">
              هل تحتاج إلى تحصيل مطالبات أو تشغيل خدمة متخصصة؟
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-sm leading-7 text-purple-50 sm:text-base">
              تواصل معنا لمراجعة احتياجك وتحديد الحل المناسب، سواء في التحصيل أو الدعم والتشغيل أو الاستشارات وإدارة المشاريع.
            </p>
            <div className="mt-8 flex justify-center">
              <RouteLink route="contact" className="inline-flex items-center justify-center gap-2 rounded-full bg-white px-7 py-3 text-sm font-extrabold text-purple-950 transition hover:bg-purple-50">
                اطلب استشارة أولية
                <ArrowLeft className="h-4 w-4" />
              </RouteLink>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function HomePage() {
  return (
    <>
      <Hero />
      <TrustStrip />
      <PreviewAbout />
      <PreviewServices />
      <PreviewProcess />
      <CapabilitiesSection />
      <SectorsSection />
      <CtaSection />
    </>
  );
}

function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="من نحن"
        icon={Building2}
        title="سداد كوم المحدودة شركة حلول احترافية متكاملة."
        subtitle="نعمل على تقديم خدمات عالية الجودة في التحصيل والحلول التشغيلية والاستشارية، مع التركيز على الابتكار والكفاءة وبناء علاقات طويلة المدى مع العملاء."
      />
      <section className="py-20 sm:py-24">
        <div className="section-container grid gap-8 lg:grid-cols-[0.92fr_1.08fr] lg:items-center">
          <Reveal>
            <div className="card p-8 sm:p-10">
              <span className="section-eyebrow">
                <Landmark className="h-4 w-4" />
                نبذة تعريفية
              </span>
              <h2 className="section-title">خبرة وجودة عالية نحو مستقبل أكثر تطورًا وابتكارًا.</h2>
              <p className="section-subtitle text-right">
                تقدم سداد كوم المحدودة خدمات احترافية متكاملة ترتكز على الجودة والابتكار، وتعمل على تقديم أفضل الحلول التي تلبي احتياجات العملاء وتواكب التطورات الحديثة في السوق.
              </p>
            </div>
          </Reveal>
          <Reveal delay={120}>
            <div className="relative overflow-hidden rounded-[2rem] border border-white bg-white p-3 shadow-2xl shadow-purple-950/10">
              <img src="./images/team.jpg" alt="سداد كوم المحدودة" className="h-[360px] w-full rounded-[1.5rem] object-cover sm:h-[470px]" />
            </div>
          </Reveal>
        </div>
      </section>

      <section className="bg-white/65 py-20 sm:py-24">
        <div className="section-container grid gap-5 lg:grid-cols-2">
          <Reveal>
            <article className="card h-full p-8 sm:p-10">
              <Target className="mb-5 h-10 w-10 text-purple-800" />
              <h2 className="text-3xl font-extrabold text-slate-950">رؤيتنا</h2>
              <p className="mt-4 text-base leading-9 text-slate-600">
                أن تكون سداد كوم المحدودة من الجهات الرائدة في تقديم الحلول والخدمات الاحترافية على مستوى المملكة والمنطقة، وأن تسهم في تطوير الأعمال من خلال الابتكار والجودة والاحترافية.
              </p>
            </article>
          </Reveal>
          <Reveal delay={120}>
            <article className="card h-full p-8 sm:p-10">
              <Mail className="mb-5 h-10 w-10 text-purple-800" />
              <h2 className="text-3xl font-extrabold text-slate-950">رسالتنا</h2>
              <p className="mt-4 text-base leading-9 text-slate-600">
                نسعى إلى تقديم خدمات عالية الجودة تعتمد على الكفاءة المهنية والتطوير المستمر، بما يحقق رضا العملاء ويعزز من طبيعة أعمالهم، ويؤسس لشراكات استراتيجية طويلة المدى.
              </p>
            </article>
          </Reveal>
        </div>
      </section>

      <section className="py-20 sm:py-24">
        <div className="section-container">
          <SectionHeading
            eyebrow="قيمنا"
            title="قيم عمل واضحة تعكس شخصية الشركة"
            subtitle="الجودة والاحترافية والشفافية والالتزام والابتكار ورضا العملاء هي الأساس الذي نبني عليه خدماتنا."
          />
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {values.map((value, index) => (
              <Reveal key={value.title} delay={index * 80}>
                <article className="card h-full p-7 text-center">
                  <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-purple-900/10 text-purple-900">
                    <value.icon className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-extrabold text-slate-950">{value.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-600">{value.description}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white/65 py-20 sm:py-24">
        <div className="section-container">
          <SectionHeading
            eyebrow="الأهداف"
            title="أهداف عملية تدعم النمو والثقة"
            subtitle="تعمل الشركة على تطوير خدماتها وتوسيع نطاق أعمالها وبناء شراكات ناجحة مع مواكبة أحدث الحلول."
          />
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {goals.map((goal, index) => (
              <Reveal key={goal.title} delay={index * 80}>
                <article className="card h-full p-7">
                  <goal.icon className="mb-5 h-9 w-9 text-purple-800" />
                  <h3 className="text-lg font-extrabold text-slate-950">{goal.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-600">{goal.description}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <CapabilitiesSection />
      <CtaSection />
    </>
  );
}

function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="خدماتنا"
        icon={BriefcaseBusiness}
        title="حلول متكاملة لنجاح أعمالك."
        subtitle="نقدم خدمات احترافية تساعد على تطوير الأعمال، تحسين الأداء، إدارة المطالبات، وتشغيل الخدمات وفق منهج واضح وجودة عالية."
      />
      <section className="py-20 sm:py-24">
        <div className="section-container grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {services.map((service, index) => (
            <Reveal key={service.title} delay={index * 80}>
              <article className="card h-full p-7">
                <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-purple-900 text-white">
                  <service.icon className="h-7 w-7" />
                </div>
                <h2 className="text-xl font-extrabold text-slate-950">{service.title}</h2>
                <p className="mt-3 text-sm leading-7 text-slate-600">{service.description}</p>
                <ul className="mt-5 space-y-3">
                  {service.points.map((point) => (
                    <li key={point} className="flex gap-3 text-sm font-semibold leading-7 text-slate-700">
                      <CheckCircle2 className="mt-1 h-5 w-5 flex-shrink-0 text-purple-800" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </article>
            </Reveal>
          ))}
        </div>
      </section>
      <CapabilitiesSection />
      <CtaSection />
    </>
  );
}

function ProcessPage() {
  return (
    <>
      <PageHero
        eyebrow="آلية العمل"
        icon={ListChecks}
        title="منهجية واضحة للتحصيل وتنفيذ الخدمات."
        subtitle="يعتمد العمل على دراسة احتياج العميل، بناء الحل المناسب، تنفيذ الإجراءات، مراقبة الجودة، وتسليم النتائج مع دعم مستمر عند الحاجة."
      />

      <section className="py-20 sm:py-24">
        <div className="section-container">
          <SectionHeading
            eyebrow="آلية العمل العامة"
            title="خمس مراحل لتنفيذ الخدمة باحترافية"
            subtitle="توضح هذه المراحل طريقة انتقال الطلب من الدراسة الأولية إلى الحل والتنفيذ ثم التسليم والدعم."
          />
          <div className="relative mx-auto max-w-5xl">
            <div className="absolute right-5 top-0 hidden h-full w-px bg-purple-900/15 md:block" />
            <div className="space-y-5">
              {processSteps.map((step, index) => (
                <Reveal key={step.number} delay={index * 70}>
                  <div className="relative grid gap-4 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm md:grid-cols-[120px_1fr] md:p-7">
                    <div className="flex items-center gap-4 md:block">
                      <div className="relative z-10 inline-flex rounded-2xl bg-purple-900 px-4 py-2 text-lg font-extrabold text-white">{step.number}</div>
                    </div>
                    <div>
                      <h2 className="text-2xl font-extrabold text-slate-950">{step.title}</h2>
                      <p className="mt-3 text-sm leading-8 text-slate-600 sm:text-base">{step.description}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white/65 py-20 sm:py-24">
        <div className="section-container">
          <SectionHeading
            eyebrow="آلية تحصيل الديون"
            title="تسع خطوات لمتابعة ملفات المديونيات"
            subtitle="توضح الآلية كيفية انتقال ملف المديونية من الاستلام والتصنيف إلى التواصل ومراقبة الجودة والتوصية بالتصعيد عند الحاجة."
          />
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {collectionMechanism.map((step, index) => (
              <Reveal key={step.number} delay={index * 60}>
                <article className="card h-full p-7">
                  <div className="mb-5 inline-flex rounded-2xl bg-slate-950 px-4 py-2 text-lg font-extrabold text-white">{step.number}</div>
                  <h3 className="text-xl font-extrabold text-slate-950">{step.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-600">{step.description}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <CtaSection />
    </>
  );
}

function SectorsPage() {
  return (
    <>
      <PageHero
        eyebrow="قطاعات العمل"
        icon={Landmark}
        title="خبرة موجهة لقطاعات متنوعة في السوق."
        subtitle="تقدم سداد كوم المحدودة حلولها لجهات متعددة، مع مراعاة اختلاف طبيعة كل قطاع ومتطلباته التشغيلية والمالية."
      />
      <SectorsSection />
      <CtaSection />
    </>
  );
}

function FaqPage() {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <>
      <PageHero
        eyebrow="الأسئلة الشائعة"
        icon={FileCheck2}
        title="إجابات مختصرة على الأسئلة التي تهم العميل قبل التواصل."
        subtitle="تعرف على طبيعة الخدمات والقطاعات وآلية العمل قبل إرسال طلب التواصل الأولي."
      />
      <section className="py-20 sm:py-24">
        <div className="section-container">
          <div className="mx-auto max-w-4xl space-y-4">
            {faqItems.map((item, index) => {
              const isOpen = openIndex === index;
              return (
                <Reveal key={item.question} delay={index * 60}>
                  <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
                    <button
                      type="button"
                      onClick={() => setOpenIndex(isOpen ? -1 : index)}
                      className="flex w-full items-center justify-between gap-4 p-5 text-right sm:p-6"
                      aria-expanded={isOpen}
                    >
                      <span className="text-base font-extrabold text-slate-950 sm:text-lg">{item.question}</span>
                      <ChevronDown className={`h-5 w-5 flex-shrink-0 text-purple-900 transition ${isOpen ? 'rotate-180' : ''}`} />
                    </button>
                    <div className={`faq-answer ${isOpen ? 'open' : ''}`}>
                      <p className="border-t border-slate-100 px-5 pb-6 pt-4 text-sm leading-8 text-slate-600 sm:px-6">{item.answer}</p>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>
      <CtaSection />
    </>
  );
}

function ContactPage() {
  const [sentMessage, setSentMessage] = useState('');

  const mailtoHref = useMemo(() => {
    const subject = encodeURIComponent('طلب استشارة من موقع سداد كوم المحدودة');
    return `mailto:${company.email}?subject=${subject}`;
  }, []);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = String(form.get('name') || '').trim();
    const organization = String(form.get('organization') || '').trim();
    const phone = String(form.get('phone') || '').trim();
    const email = String(form.get('email') || '').trim();
    const serviceType = String(form.get('serviceType') || '').trim();
    const sector = String(form.get('sector') || '').trim();
    const message = String(form.get('message') || '').trim();

    const body = [
      'مرحبًا، أود طلب استشارة من سداد كوم المحدودة.',
      `الاسم: ${name}`,
      `الشركة/الجهة: ${organization}`,
      `رقم الجوال: ${phone}`,
      email ? `البريد: ${email}` : '',
      `نوع الخدمة المطلوبة: ${serviceType}`,
      sector ? `القطاع: ${sector}` : '',
      `ملخص الطلب: ${message}`,
    ]
      .filter(Boolean)
      .join('\n');

    const whatsappUrl = `https://wa.me/${company.phoneLink}?text=${encodeURIComponent(body)}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    setSentMessage('تم تجهيز رسالة واتساب ببيانات طلبك. يمكنك مراجعتها وإرسالها لإكمال التواصل.');
    event.currentTarget.reset();
  }

  return (
    <>
      <PageHero
        eyebrow="تواصل معنا"
        icon={Mail}
        title="يسعدنا تواصلكم واستقبال استفساراتكم في أي وقت."
        subtitle="أرسل طلبك الأولي وسيساعدك فريق سداد كوم المحدودة في تحديد الحل الأنسب، سواء للتحصيل أو التشغيل أو الاستشارات أو إدارة المشاريع."
      />
      <section className="py-20 sm:py-24">
        <div className="section-container grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
          <Reveal>
            <div>
              <span className="section-eyebrow">
                <Send className="h-4 w-4" />
                بيانات التواصل
              </span>
              <h2 className="section-title">قنوات واضحة للتواصل مع الشركة.</h2>
              <p className="section-subtitle text-right">
                يمكنك التواصل مباشرة عبر الهاتف أو البريد الإلكتروني، أو تعبئة النموذج ليتم تجهيز رسالة واتساب تحتوي بيانات طلبك بشكل منظم.
              </p>

              <div className="mt-8 space-y-4">
                <a href={`tel:${company.phoneDisplay}`} className="contact-card">
                  <div className="contact-icon">
                    <Phone className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-500">الهاتف</p>
                    <p className="font-extrabold text-slate-950">{company.phoneDisplay}</p>
                  </div>
                </a>
                <a href={mailtoHref} className="contact-card">
                  <div className="contact-icon">
                    <Mail className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-500">البريد الإلكتروني</p>
                    <p className="break-all font-extrabold text-slate-950">{company.email}</p>
                  </div>
                </a>
                <div className="contact-card">
                  <div className="contact-icon">
                    <MapPin className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-500">النطاق الجغرافي</p>
                    <p className="font-extrabold text-slate-950">{company.location}</p>
                    <p className="mt-1 text-sm text-slate-500">{company.workingHours}</p>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <form onSubmit={handleSubmit} className="card p-6 sm:p-8">
              <div className="grid gap-5 sm:grid-cols-2">
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  الاسم الكامل
                  <input className="input-field" name="name" placeholder="اكتب اسمك" required />
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  اسم الشركة أو الجهة
                  <input className="input-field" name="organization" placeholder="اسم الشركة أو المؤسسة" required />
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  رقم الجوال
                  <input className="input-field" name="phone" placeholder="05xxxxxxxx" inputMode="tel" required />
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  البريد الإلكتروني
                  <input className="input-field" name="email" placeholder="name@example.com" type="email" />
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  نوع الخدمة المطلوبة
                  <select className="input-field" name="serviceType" defaultValue="" required>
                    <option value="" disabled>
                      اختر نوع الخدمة
                    </option>
                    <option>تحصيل الديون وإدارة المطالبات</option>
                    <option>خدمات الدعم والتشغيل</option>
                    <option>الاستشارات والتطوير</option>
                    <option>إدارة وتنفيذ المشاريع</option>
                    <option>خدمات المتابعة والصيانة</option>
                    <option>استفسار عام</option>
                  </select>
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  القطاع
                  <input className="input-field" name="sector" placeholder="مثال: مالي، صحي، تجزئة" />
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700 sm:col-span-2">
                  ملخص الطلب
                  <textarea className="input-field min-h-36 resize-y" name="message" placeholder="اكتب ملخصًا مختصرًا عن الخدمة المطلوبة" required />
                </label>
              </div>
              <button type="submit" className="primary-button mt-6 w-full">
                <MessageCircle className="h-5 w-5" />
                إرسال الطلب عبر واتساب
              </button>
              {sentMessage ? <p className="mt-4 rounded-2xl bg-purple-50 p-4 text-sm font-bold leading-7 text-purple-900">{sentMessage}</p> : null}
              <p className="mt-4 text-center text-xs leading-6 text-slate-500">
                يتم استخدام بيانات التواصل للرد على طلبك ومراجعة الاستفسار الأولي فقط.
              </p>
            </form>
          </Reveal>
        </div>
      </section>
    </>
  );
}

function PrivacyPage() {
  return (
    <>
      <PageHero
        eyebrow="سياسة الخصوصية"
        icon={LockKeyhole}
        title="نتعامل مع بيانات العملاء باعتبارها معلومات حساسة."
        subtitle="توضح هذه السياسة طريقة استخدام بيانات التواصل والمعلومات الأولية التي يرسلها الزائر عبر الموقع."
      />
      <LegalContent
        items={[
          {
            title: 'استخدام البيانات',
            text: 'تستخدم بيانات نموذج التواصل للرد على الاستفسارات ومراجعة الطلب الأولي فقط، ولا تستخدم لأغراض أخرى خارج نطاق التواصل مع العميل.',
          },
          {
            title: 'سرية الملفات والمطالبات',
            text: 'أي معلومات تتعلق بالمطالبات المالية أو الخدمات التشغيلية أو الأطراف ذات العلاقة تعامل بسرية، ولا تتم مشاركتها إلا ضمن نطاق الخدمة أو وفق المتطلبات النظامية.',
          },
          {
            title: 'المستندات الحساسة',
            text: 'يفضل عدم إرسال مستندات مالية أو تشغيلية حساسة عبر نموذج عام. عند الحاجة إلى مستندات يتم تحديد قناة مناسبة لتبادلها مع الجهة المخولة.',
          },
          {
            title: 'تحديث السياسة',
            text: 'قد يتم تحديث سياسة الخصوصية عند إضافة خدمات جديدة أو تغيير آلية استقبال الطلبات، ويعد استمرار استخدام الموقع قبولًا بالسياسة المحدثة.',
          },
        ]}
      />
    </>
  );
}

function TermsPage() {
  return (
    <>
      <PageHero
        eyebrow="شروط الاستخدام"
        icon={FileText}
        title="معلومات الموقع تعريفية وتوضح نطاق الخدمات."
        subtitle="تحدد هذه الشروط طبيعة المعلومات المنشورة في الموقع وطريقة استخدام خدمات التواصل الأولي."
      />
      <LegalContent
        items={[
          {
            title: 'طبيعة المعلومات',
            text: 'المحتوى المنشور في الموقع يهدف إلى التعريف بالشركة وخدماتها وطريقة العمل، ولا يعد تعهدًا بنتيجة محددة قبل دراسة الطلب وتحديد نطاق الخدمة.',
          },
          {
            title: 'تقييم كل طلب',
            text: 'يتم تقييم كل طلب حسب بياناته ومستنداته وقطاعه ونطاق الخدمة المطلوبة، ثم يتم تحديد المسار المناسب بعد المراجعة.',
          },
          {
            title: 'نطاق الخدمة والتكلفة',
            text: 'يتم تحديد نطاق الخدمة والتكلفة بعد فهم الطلب وتوضيح المتطلبات وموافقة العميل، ولا تعتبر المعلومات العامة المنشورة عرضًا نهائيًا ملزمًا.',
          },
          {
            title: 'الاستخدام الصحيح للموقع',
            text: 'يجب على الزائر تقديم معلومات صحيحة عند التواصل، وعدم إرسال بيانات تخص أطرافًا أخرى دون صفة أو تفويض مناسب.',
          },
        ]}
      />
    </>
  );
}

function LegalContent({ items }: { items: { title: string; text: string }[] }) {
  return (
    <section className="py-20 sm:py-24">
      <div className="section-container mx-auto max-w-4xl space-y-5">
        {items.map((item, index) => (
          <Reveal key={item.title} delay={index * 80}>
            <article className="card p-7 sm:p-8">
              <h2 className="text-2xl font-extrabold text-slate-950">{item.title}</h2>
              <p className="mt-4 text-sm leading-8 text-slate-600 sm:text-base">{item.text}</p>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-slate-950 py-10 text-white">
      <div className="section-container flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="flex items-center gap-3">
            <div className="brand-mark flex h-11 w-11 items-center justify-center rounded-2xl text-xl font-black text-white">S</div>
            <div>
              <p className="font-extrabold">{company.name}</p>
              <p className="text-sm tracking-wide text-slate-400">{company.enName}</p>
            </div>
          </div>
          <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-400">
            حلول احترافية متكاملة في التحصيل والدعم والتشغيل والاستشارات وإدارة المشاريع، بجودة عالية ومنهج عمل واضح.
          </p>
        </div>
        <div className="flex flex-wrap gap-3 text-sm font-bold text-slate-300">
          <RouteLink route="privacy" className="hover:text-white">الخصوصية</RouteLink>
          <span className="text-slate-600">/</span>
          <RouteLink route="terms" className="hover:text-white">الشروط</RouteLink>
          <span className="text-slate-600">/</span>
          <RouteLink route="contact" className="hover:text-white">تواصل معنا</RouteLink>
        </div>
      </div>
    </footer>
  );
}

function FloatingActions() {
  const message = encodeURIComponent('مرحبًا، أريد الاستفسار عن خدمات سداد كوم المحدودة.');
  return (
    <div className="fixed bottom-5 left-5 z-40 flex flex-col gap-3 print:hidden">
      <a
        href={`https://wa.me/${company.phoneLink}?text=${message}`}
        target="_blank"
        rel="noreferrer"
        className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-600 text-white shadow-xl shadow-emerald-900/20 transition hover:scale-105"
        aria-label="واتساب"
      >
        <MessageCircle className="h-6 w-6" />
      </a>
      <a
        href={`tel:${company.phoneDisplay}`}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-purple-950 text-white shadow-xl shadow-purple-950/20 transition hover:scale-105"
        aria-label="اتصال"
      >
        <Phone className="h-6 w-6" />
      </a>
    </div>
  );
}

function CurrentPage({ route }: { route: RouteKey }) {
  if (route === 'about') return <AboutPage />;
  if (route === 'services') return <ServicesPage />;
  if (route === 'process') return <ProcessPage />;
  if (route === 'sectors') return <SectorsPage />;
  if (route === 'faq') return <FaqPage />;
  if (route === 'contact') return <ContactPage />;
  if (route === 'privacy') return <PrivacyPage />;
  if (route === 'terms') return <TermsPage />;
  return <HomePage />;
}

export default function App() {
  const route = useRoute();

  return (
    <main>
      <Navigation activeRoute={route} />
      <CurrentPage route={route} />
      <Footer />
      <FloatingActions />
    </main>
  );
}
