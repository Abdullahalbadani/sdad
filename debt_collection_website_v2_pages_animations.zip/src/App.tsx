import type { FormEvent, ReactNode } from 'react';
import { useEffect, useMemo, useRef, useState } from 'react';
import type { LucideIcon } from 'lucide-react';
import {
  ArrowLeft,
  Banknote,
  BarChart3,
  BriefcaseBusiness,
  Building2,
  CheckCircle2,
  ChevronDown,
  ClipboardCheck,
  Clock3,
  Eye,
  FileCheck2,
  FileText,
  Handshake,
  Home,
  Landmark,
  ListChecks,
  LockKeyhole,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  Scale,
  Send,
  ShieldCheck,
  Sparkles,
  Target,
  Users,
  X,
} from 'lucide-react';

type RouteKey = 'home' | 'about' | 'services' | 'process' | 'faq' | 'contact' | 'privacy' | 'terms';

type CardItem = {
  icon: LucideIcon;
  title: string;
  description: string;
};

type ServiceItem = CardItem & {
  points: string[];
};

type FaqItem = {
  question: string;
  answer: string;
};

const company = {
  name: 'شركة التحصيل',
  slogan: 'متابعة المطالبات المالية باحترافية وهدوء',
  phoneDisplay: '+966 50 000 0000',
  phoneLink: '966500000000',
  email: 'info@example.com',
  location: 'المملكة العربية السعودية',
  workingHours: 'الأحد - الخميس، 9 صباحًا - 5 مساءً',
};

const navLinks: { label: string; route: RouteKey; icon: LucideIcon }[] = [
  { label: 'الرئيسية', route: 'home', icon: Home },
  { label: 'من نحن', route: 'about', icon: Building2 },
  { label: 'خدماتنا', route: 'services', icon: BriefcaseBusiness },
  { label: 'آلية العمل', route: 'process', icon: ListChecks },
  { label: 'الأسئلة الشائعة', route: 'faq', icon: FileCheck2 },
  { label: 'تواصل معنا', route: 'contact', icon: Mail },
];

const services: ServiceItem[] = [
  {
    icon: Banknote,
    title: 'تحصيل الديون التجارية',
    description:
      'متابعة المستحقات المتأخرة بين الشركات والموردين والعملاء التجاريين بأسلوب مهني يحافظ على العلاقة ويقلل النزاعات.',
    points: ['مراجعة طبيعة العلاقة التجارية', 'تحديد أولويات المتابعة', 'التواصل الرسمي باسم الجهة المخولة'],
  },
  {
    icon: Handshake,
    title: 'التسويات الودية وجدولة السداد',
    description:
      'التواصل مع الطرف المدين للوصول إلى حلول سداد واضحة وقابلة للتنفيذ قبل الانتقال لأي إجراء تصعيدي.',
    points: ['اقتراح حلول سداد واقعية', 'توثيق الاتفاقات الأساسية', 'متابعة الالتزام بجدول السداد'],
  },
  {
    icon: ClipboardCheck,
    title: 'إدارة المطالبات المالية',
    description:
      'تنظيم بيانات المطالبة، فرز الحالات، تحديد الأولويات، وتقديم متابعة منظمة لصاحب المطالبة.',
    points: ['فرز الملفات حسب الأهمية', 'حصر البيانات الناقصة', 'تحديد الإجراء المناسب لكل حالة'],
  },
  {
    icon: FileText,
    title: 'تقارير متابعة دورية',
    description:
      'تزويد العميل بملخصات واضحة حول حالة كل مطالبة، آخر إجراء، الردود، والتوصيات المناسبة للمرحلة التالية.',
    points: ['توضيح آخر إجراء تم', 'عرض حالة كل مطالبة', 'تقديم توصيات عملية للخطوة التالية'],
  },
  {
    icon: Scale,
    title: 'التوصية بالإجراء النظامي',
    description:
      'عند تعذر التسوية الودية، يتم توضيح الخيارات المناسبة للعميل وإرشاده إلى القنوات النظامية ذات العلاقة.',
    points: ['تقييم جدوى التصعيد', 'توضيح المتطلبات الأساسية', 'إرشاد العميل للمسار الأنسب'],
  },
  {
    icon: LockKeyhole,
    title: 'حماية بيانات المطالبات',
    description:
      'التعامل مع بيانات العملاء والمستندات المالية بسرية، مع حصر الوصول للأشخاص المخولين فقط.',
    points: ['تقليل تداول البيانات الحساسة', 'اعتماد قنوات تواصل واضحة', 'حصر المعلومات حسب حاجة الخدمة'],
  },
];

const processSteps = [
  {
    number: '01',
    title: 'استقبال الطلب',
    description: 'يتم استقبال بيانات المطالبة الأساسية وفهم طبيعة العلاقة وقيمة المستحقات والمدة الزمنية للتأخير.',
  },
  {
    number: '02',
    title: 'مراجعة البيانات',
    description: 'تتم مراجعة المعلومات المتاحة وتحديد ما إذا كانت الحالة تحتاج مستندات إضافية قبل بدء المتابعة.',
  },
  {
    number: '03',
    title: 'دراسة الحالة',
    description: 'نحدد الأسلوب الأنسب للتواصل والمتابعة بناءً على نوع المطالبة وطبيعة الطرف المدين.',
  },
  {
    number: '04',
    title: 'التواصل المهني',
    description: 'يتم التواصل بصياغة رسمية وهادئة تركز على الحل والسداد دون إساءة أو ضغط غير مناسب.',
  },
  {
    number: '05',
    title: 'التفاوض والتسوية',
    description: 'يتم بحث خيارات السداد الكامل أو الجزئي أو الجدولة وفق موافقة العميل وحدود الحالة.',
  },
  {
    number: '06',
    title: 'المتابعة والتقرير',
    description: 'يحصل العميل على تحديث واضح يوضح آخر إجراء، رد الطرف الآخر، والخطوة المقترحة التالية.',
  },
  {
    number: '07',
    title: 'إغلاق الملف أو التصعيد',
    description: 'تنتهي الحالة بسداد، اتفاق، إغلاق، أو توصية بمسار نظامي عند تعذر التسوية الودية.',
  },
];

const sectors = [
  'الشركات التجارية',
  'الموردون والمقاولون',
  'المؤسسات الصغيرة والمتوسطة',
  'مكاتب الخدمات',
  'الشركات الخدمية',
  'العيادات والمراكز الخاصة',
  'مزودو الاشتراكات والخدمات الدورية',
  'الجهات التي لديها مطالبات متكررة',
];

const values: CardItem[] = [
  {
    icon: ShieldCheck,
    title: 'السرية',
    description: 'التعامل مع بيانات العملاء والمطالبات باعتبارها معلومات حساسة لا تستخدم إلا لغرض الخدمة.',
  },
  {
    icon: Scale,
    title: 'المهنية',
    description: 'لغة تواصل رسمية، خطوات واضحة، وتجنب أي أسلوب قد يضر بسمعة العميل أو العلاقة التجارية.',
  },
  {
    icon: Target,
    title: 'التركيز على الحل',
    description: 'الأولوية للوصول إلى تسوية عملية أو قرار واضح بدل إطالة المتابعة دون نتيجة.',
  },
  {
    icon: BarChart3,
    title: 'الوضوح',
    description: 'تقارير مختصرة توضّح حالة المطالبة وما تم تنفيذه وما يُقترح بعد ذلك.',
  },
];

const whyUs: CardItem[] = [
  {
    icon: ShieldCheck,
    title: 'أسلوب يحمي سمعة العميل',
    description: 'المتابعة تتم بلغة مهنية تضع سمعة صاحب المطالبة في الاعتبار من أول تواصل حتى إغلاق الحالة.',
  },
  {
    icon: Clock3,
    title: 'خطوات منظمة',
    description: 'كل مطالبة تمر بمراجعة ودراسة وتواصل وتقرير حتى يعرف العميل أين وصلت الحالة.',
  },
  {
    icon: Eye,
    title: 'شفافية في المتابعة',
    description: 'لا يتم تقديم وعود مطلقة؛ بل يتم شرح الوضع والخيارات المتاحة بناءً على بيانات كل حالة.',
  },
  {
    icon: Users,
    title: 'فهم لطبيعة الشركات',
    description: 'التعامل مع المطالبات كجزء من إدارة التدفق النقدي والعلاقات التجارية، وليس كمجرد اتصالات عشوائية.',
  },
];

const faqItems: FaqItem[] = [
  {
    question: 'هل تتم المتابعة بطريقة نظامية؟',
    answer:
      'تتم المتابعة بأسلوب مهني ومنظم، مع مراعاة الأنظمة المعمول بها وطبيعة العلاقة بين الأطراف، وتجنب أي ممارسات مسيئة أو غير مناسبة.',
  },
  {
    question: 'هل يتم الحفاظ على سرية البيانات؟',
    answer:
      'نعم، بيانات العملاء والمطالبات والمستندات المالية تعامل كمعلومات حساسة، ولا تستخدم إلا لغرض دراسة الطلب وتنفيذ الخدمة المتفق عليها.',
  },
  {
    question: 'هل يمكن الوصول إلى تسوية ودية؟',
    answer:
      'في كثير من الحالات يكون المسار الودي وجدولة السداد خيارًا عمليًا قبل التفكير في أي مسار تصعيدي، ويعتمد ذلك على تجاوب الطرف المدين وطبيعة المطالبة.',
  },
  {
    question: 'كيف أبدأ طلب الخدمة؟',
    answer:
      'يمكنك التواصل عبر النموذج أو الواتساب وتقديم وصف مختصر للحالة، ثم يتم تحديد البيانات المطلوبة لدراسة المطالبة واختيار المسار المناسب.',
  },
  {
    question: 'هل توجد رسوم محددة لكل حالة؟',
    answer:
      'تختلف الرسوم حسب نوع المطالبة وقيمتها وعدد الحالات ودرجة تعقيدها. يتم تحديد التفاصيل بعد مراجعة الطلب وتوضيح نطاق الخدمة.',
  },
  {
    question: 'هل أرسل المستندات من النموذج؟',
    answer:
      'يفضل أن يكون النموذج للتواصل الأولي فقط. عند الحاجة إلى مستندات، يتم تحديد قناة مناسبة وآمنة لتبادلها مع الجهة المخولة.',
  },
];

const routeLabels: Record<RouteKey, string> = {
  home: 'الرئيسية',
  about: 'من نحن',
  services: 'خدماتنا',
  process: 'آلية العمل',
  faq: 'الأسئلة الشائعة',
  contact: 'تواصل معنا',
  privacy: 'سياسة الخصوصية',
  terms: 'شروط الاستخدام',
};

function hrefFor(route: RouteKey) {
  return route === 'home' ? '#/' : `#/${route}`;
}

function getRouteFromHash(): RouteKey {
  const value = window.location.hash.replace(/^#\/?/, '') || 'home';
  const routes: RouteKey[] = ['home', 'about', 'services', 'process', 'faq', 'contact', 'privacy', 'terms'];
  return routes.includes(value as RouteKey) ? (value as RouteKey) : 'home';
}

function useRoute() {
  const [route, setRoute] = useState<RouteKey>(() => getRouteFromHash());

  useEffect(() => {
    const onHashChange = () => setRoute(getRouteFromHash());
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    document.title = `${routeLabels[route]} | ${company.name}`;
  }, [route]);

  return route;
}

function Reveal({ children, className = '', delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(() =>
    typeof window !== 'undefined' ? window.matchMedia('(prefers-reduced-motion: reduce)').matches : false,
  );

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;

    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.16, rootMargin: '0px 0px -8% 0px' },
    );

    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className={`reveal ${visible ? 'is-visible' : ''} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

function SectionHeading({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle: string }) {
  return (
    <Reveal className="mx-auto mb-12 max-w-3xl text-center">
      <span className="section-eyebrow">
        <Sparkles className="h-4 w-4" />
        {eyebrow}
      </span>
      <h2 className="section-title">{title}</h2>
      <p className="section-subtitle">{subtitle}</p>
    </Reveal>
  );
}

function PageHero({ eyebrow, title, subtitle, icon: Icon }: { eyebrow: string; title: string; subtitle: string; icon: LucideIcon }) {
  return (
    <section className="relative overflow-hidden bg-slate-950 py-16 text-white sm:py-20 lg:py-24">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(34,211,238,0.18),transparent_34%),radial-gradient(circle_at_bottom_left,rgba(255,255,255,0.08),transparent_30%)]" />
      <div className="section-container relative">
        <Reveal className="max-w-4xl">
          <span className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-bold text-cyan-100">
            <Icon className="h-4 w-4" />
            {eyebrow}
          </span>
          <h1 className="text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl lg:text-6xl">{title}</h1>
          <p className="mt-6 max-w-3xl text-base leading-8 text-slate-300 sm:text-lg">{subtitle}</p>
        </Reveal>
      </div>
    </section>
  );
}

function RouteLink({
  route,
  children,
  className = '',
  onClick,
  ariaLabel,
}: {
  route: RouteKey;
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  ariaLabel?: string;
}) {
  return (
    <a href={hrefFor(route)} className={className} onClick={onClick} aria-label={ariaLabel}>
      {children}
    </a>
  );
}

function ContactButtons({ compact = false }: { compact?: boolean }) {
  const message = encodeURIComponent('مرحبًا، أود الاستفسار عن خدمات تحصيل المطالبات المالية.');
  return (
    <div className={`flex flex-col gap-3 sm:flex-row ${compact ? 'sm:justify-start' : 'justify-center'}`}>
      <a className="primary-button" href={`https://wa.me/${company.phoneLink}?text=${message}`} target="_blank" rel="noreferrer">
        <MessageCircle className="h-5 w-5" />
        تواصل عبر واتساب
      </a>
      <RouteLink route="contact" className="secondary-button">
        <Mail className="h-5 w-5" />
        اطلب استشارة
      </RouteLink>
    </div>
  );
}

function Navigation({ activeRoute }: { activeRoute: RouteKey }) {
  const [isOpen, setIsOpen] = useState(false);
  const closeMenu = () => setIsOpen(false);

  return (
    <header className="sticky top-0 z-50 animate-nav border-b border-white/50 bg-white/90 backdrop-blur-xl">
      <div className="section-container flex h-20 items-center justify-between">
        <RouteLink route="home" onClick={closeMenu} className="flex min-w-0 items-center gap-3" ariaLabel="الانتقال للرئيسية">
          <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-2xl bg-cyan-900 text-lg font-extrabold text-white shadow-lg shadow-cyan-900/20">
            ش
          </div>
          <div className="min-w-0">
            <p className="truncate text-lg font-extrabold text-slate-950">{company.name}</p>
            <p className="hidden text-xs font-semibold text-slate-500 sm:block">{company.slogan}</p>
          </div>
        </RouteLink>

        <nav className="hidden items-center gap-2 lg:flex" aria-label="روابط الموقع">
          {navLinks.map((link) => {
            const isActive = activeRoute === link.route;
            return (
              <RouteLink
                key={link.route}
                route={link.route}
                className={`rounded-full px-4 py-2 text-sm font-bold transition ${
                  isActive ? 'bg-cyan-900 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100 hover:text-cyan-900'
                }`}
              >
                {link.label}
              </RouteLink>
            );
          })}
        </nav>

        <div className="hidden lg:block">
          <RouteLink route="contact" className="primary-button">
            اطلب استشارة
            <ArrowLeft className="h-4 w-4" />
          </RouteLink>
        </div>

        <button
          type="button"
          onClick={() => setIsOpen((current) => !current)}
          className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-800 lg:hidden"
          aria-label="فتح القائمة"
          aria-expanded={isOpen}
        >
          {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {isOpen ? (
        <div className="mobile-menu border-t border-slate-100 bg-white lg:hidden">
          <div className="section-container grid gap-2 py-4">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = activeRoute === link.route;
              return (
                <RouteLink
                  key={link.route}
                  route={link.route}
                  onClick={closeMenu}
                  className={`flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-bold transition ${
                    isActive ? 'bg-cyan-900 text-white' : 'text-slate-700 hover:bg-slate-50 hover:text-cyan-900'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {link.label}
                </RouteLink>
              );
            })}
          </div>
        </div>
      ) : null}
    </header>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden py-16 sm:py-20 lg:py-24">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top_right,rgba(14,116,144,0.12),transparent_35%),radial-gradient(circle_at_bottom_left,rgba(15,23,42,0.08),transparent_30%)]" />
      <div className="section-container grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
        <div>
          <Reveal>
            <span className="section-eyebrow">
              <ShieldCheck className="h-4 w-4" />
              حلول مهنية لمتابعة المطالبات المالية
            </span>
          </Reveal>
          <Reveal delay={90}>
            <h1 className="max-w-4xl text-4xl font-extrabold leading-[1.25] tracking-tight text-slate-950 sm:text-5xl lg:text-6xl">
              استرداد المستحقات المالية بأسلوب منظم يحفظ السمعة والثقة.
            </h1>
          </Reveal>
          <Reveal delay={160}>
            <p className="mt-6 max-w-2xl text-lg leading-9 text-slate-600">
              نساعد الشركات والمؤسسات على متابعة مطالباتها المالية من خلال دراسة دقيقة للحالة، تواصل مهني، حلول تسوية واضحة، وتقارير متابعة تحفظ حق العميل وتراعي خصوصية البيانات.
            </p>
          </Reveal>

          <Reveal delay={230} className="mt-8">
            <ContactButtons compact />
          </Reveal>

          <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:max-w-2xl">
            {['تواصل رسمي وهادئ', 'سرية في التعامل مع البيانات', 'تقارير متابعة واضحة', 'دراسة الحالة قبل تحديد المسار'].map((item, index) => (
              <Reveal key={item} delay={280 + index * 80}>
                <div className="flex items-center gap-3 rounded-2xl border border-white/70 bg-white/75 p-4 shadow-sm backdrop-blur">
                  <CheckCircle2 className="h-5 w-5 flex-shrink-0 text-cyan-800" />
                  <span className="text-sm font-bold text-slate-700">{item}</span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>

        <Reveal delay={140} className="relative">
          <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-cyan-600/10 blur-3xl" />
          <div className="absolute -bottom-8 -left-8 h-48 w-48 rounded-full bg-slate-900/10 blur-3xl" />
          <div className="relative overflow-hidden rounded-[2rem] border border-white/70 bg-white p-3 shadow-2xl shadow-cyan-950/10">
            <img src="./images/team.jpg" alt="فريق عمل في اجتماع مهني" className="h-[320px] w-full rounded-[1.5rem] object-cover sm:h-[420px]" />
            <div className="absolute inset-x-5 bottom-5 rounded-3xl bg-slate-950/85 p-5 text-white backdrop-blur-md sm:inset-x-6 sm:bottom-6">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-2xl bg-cyan-500/20">
                  <Landmark className="h-6 w-6 text-cyan-200" />
                </div>
                <div>
                  <p className="text-base font-extrabold sm:text-lg">واجهة رسمية لمجال يحتاج ثقة</p>
                  <p className="mt-1 text-sm leading-6 text-slate-200">
                    وضوح في الخدمة، لغة مهنية، وتركيز على السرية وسهولة التواصل.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function TrustStrip() {
  const stats = [
    { label: 'إجراءات المتابعة', value: 'منظمة' },
    { label: 'بيانات العملاء', value: 'سرية' },
    { label: 'أسلوب التواصل', value: 'مهني' },
    { label: 'نتائج العمل', value: 'موثقة' },
  ];

  return (
    <section className="py-8">
      <div className="section-container">
        <div className="grid gap-4 rounded-3xl border border-cyan-900/10 bg-white p-4 shadow-sm sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((item, index) => (
            <Reveal key={item.label} delay={index * 80}>
              <div className="rounded-2xl bg-slate-50 p-5 text-center">
                <p className="text-2xl font-extrabold text-cyan-900">{item.value}</p>
                <p className="mt-1 text-sm font-bold text-slate-500">{item.label}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function PreviewAbout() {
  return (
    <section className="py-20 sm:py-24">
      <div className="section-container grid gap-10 lg:grid-cols-[0.95fr_1.05fr] lg:items-center">
        <Reveal>
          <div className="card p-8 sm:p-10">
            <span className="section-eyebrow">
              <Building2 className="h-4 w-4" />
              من نحن
            </span>
            <h2 className="section-title">نساعد الشركات على متابعة مستحقاتها المالية دون إرباك أعمالها.</h2>
            <p className="section-subtitle text-right">
              تعتمد الشركة على أسلوب عمل يجمع بين الدراسة، التواصل المنظم، ومحاولة الوصول إلى حلول ودية تحفظ حقوق العميل وتراعي العلاقة التجارية مع الطرف الآخر.
            </p>
            <RouteLink route="about" className="primary-button mt-7">
              معرفة المزيد
              <ArrowLeft className="h-4 w-4" />
            </RouteLink>
          </div>
        </Reveal>

        <div className="grid gap-5 sm:grid-cols-2">
          {whyUs.map((item, index) => (
            <Reveal key={item.title} delay={index * 90}>
              <div className="card h-full p-7">
                <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-900/10 text-cyan-900">
                  <item.icon className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-extrabold text-slate-950">{item.title}</h3>
                <p className="mt-3 text-sm leading-7 text-slate-600">{item.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function PreviewServices() {
  return (
    <section className="bg-white/60 py-20 sm:py-24">
      <div className="section-container">
        <SectionHeading
          eyebrow="خدماتنا"
          title="خدمات مصممة لمتابعة المطالبات المالية بوضوح"
          subtitle="نقدم خدمات أساسية تساعد العميل على فهم طبيعة المتابعة، من دراسة المطالبة إلى التسوية والتقارير."
        />
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {services.slice(0, 3).map((service, index) => (
            <Reveal key={service.title} delay={index * 100}>
              <article className="card h-full p-7">
                <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-900 text-white">
                  <service.icon className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-extrabold text-slate-950">{service.title}</h3>
                <p className="mt-3 text-sm leading-7 text-slate-600">{service.description}</p>
              </article>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-8 text-center">
          <RouteLink route="services" className="secondary-button">
            المزيد من الخدمات
            <ArrowLeft className="h-4 w-4" />
          </RouteLink>
        </Reveal>
      </div>
    </section>
  );
}

function PreviewProcess() {
  return (
    <section className="py-20 sm:py-24">
      <div className="section-container">
        <SectionHeading
          eyebrow="آلية العمل"
          title="مسار واضح من الطلب الأولي حتى التقرير"
          subtitle="تبدأ الخدمة بفهم الطلب ومراجعة البيانات، ثم اختيار أسلوب المتابعة المناسب وتوضيح النتيجة للعميل."
        />
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {processSteps.slice(0, 4).map((step, index) => (
            <Reveal key={step.number} delay={index * 90}>
              <div className="card h-full p-6">
                <div className="mb-5 inline-flex rounded-2xl bg-slate-950 px-4 py-2 text-lg font-extrabold text-white">{step.number}</div>
                <h3 className="text-lg font-extrabold text-slate-950">{step.title}</h3>
                <p className="mt-3 text-sm leading-7 text-slate-600">{step.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-8 text-center">
          <RouteLink route="process" className="secondary-button">
            عرض جميع الخطوات
            <ArrowLeft className="h-4 w-4" />
          </RouteLink>
        </Reveal>
      </div>
    </section>
  );
}

function SectorsSection() {
  return (
    <section className="bg-slate-950 py-20 text-white sm:py-24">
      <div className="section-container grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
        <Reveal>
          <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-bold text-cyan-100">
            <Users className="h-4 w-4" />
            القطاعات التي نخدمها
          </span>
          <h2 className="text-3xl font-extrabold leading-tight sm:text-4xl">حلول مناسبة للشركات التي لديها مستحقات متأخرة.</h2>
          <p className="mt-5 text-base leading-8 text-slate-300">
            نخدم أصحاب الأعمال والجهات التي تحتاج إلى متابعة منظمة للفواتير والالتزامات المالية المتأخرة.
          </p>
        </Reveal>
        <div className="grid gap-4 sm:grid-cols-2">
          {sectors.map((sector, index) => (
            <Reveal key={sector} delay={index * 55}>
              <div className="flex h-full items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
                <CheckCircle2 className="h-5 w-5 flex-shrink-0 text-cyan-300" />
                <span className="font-bold text-slate-100">{sector}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function CtaSection() {
  return (
    <section className="py-16 sm:py-20">
      <div className="section-container">
        <Reveal>
          <div className="overflow-hidden rounded-[2rem] bg-cyan-900 p-8 text-center text-white shadow-2xl shadow-cyan-950/15 sm:p-12">
            <p className="text-sm font-bold text-cyan-100">ابدأ بخطوة واضحة</p>
            <h2 className="mx-auto mt-3 max-w-3xl text-3xl font-extrabold leading-tight sm:text-4xl">
              لديك مطالبات مالية متأخرة؟ تواصل معنا لمراجعة الحالة وتحديد المسار المناسب.
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-sm leading-7 text-cyan-50 sm:text-base">
              شارك ملخصًا أوليًا فقط، وسيتم التواصل معك لمعرفة التفاصيل المطلوبة بطريقة منظمة وآمنة.
            </p>
            <div className="mt-8 flex justify-center">
              <RouteLink route="contact" className="inline-flex items-center justify-center gap-2 rounded-full bg-white px-7 py-3 text-sm font-extrabold text-cyan-950 transition hover:bg-cyan-50">
                اطلب استشارة أولية
                <ArrowLeft className="h-4 w-4" />
              </RouteLink>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function HomePage() {
  return (
    <>
      <Hero />
      <TrustStrip />
      <PreviewAbout />
      <PreviewServices />
      <PreviewProcess />
      <SectorsSection />
      <CtaSection />
    </>
  );
}

function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="من نحن"
        icon={Building2}
        title="شركة متخصصة في متابعة المطالبات المالية بأسلوب مهني ومنظم."
        subtitle="نركز على مساعدة الشركات والمؤسسات في استرداد مستحقاتها بطريقة واضحة تحافظ على السرية والسمعة وتراعي العلاقة التجارية بين الأطراف."
      />
      <section className="py-20 sm:py-24">
        <div className="section-container grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
          <Reveal>
            <div className="card p-8 sm:p-10">
              <span className="section-eyebrow">
                <Landmark className="h-4 w-4" />
                رسالتنا
              </span>
              <h2 className="section-title">استرداد الحقوق المالية دون الإضرار بثقة السوق.</h2>
              <p className="section-subtitle text-right">
                تعمل الشركة على إدارة التواصل مع الأطراف المدينة بطريقة رسمية، وتقديم حلول سداد وتسوية واضحة، مع تزويد العميل بصورة دقيقة عن حالة المطالبة والخيارات المتاحة.
              </p>
            </div>
          </Reveal>
          <Reveal delay={120}>
            <div className="relative overflow-hidden rounded-[2rem] border border-white bg-white p-3 shadow-2xl shadow-cyan-950/10">
              <img src="./images/team.jpg" alt="فريق عمل يناقش مطالبات مالية" className="h-[360px] w-full rounded-[1.5rem] object-cover sm:h-[470px]" />
            </div>
          </Reveal>
        </div>
      </section>

      <section className="bg-white/60 py-20 sm:py-24">
        <div className="section-container">
          <SectionHeading
            eyebrow="قيم العمل"
            title="قيم واضحة تناسب مجالًا حساسًا مثل التحصيل"
            subtitle="تعتمد خدماتنا على السرية والمهنية والوضوح، لأن متابعة المطالبات المالية تحتاج إلى ثقة قبل أي إجراء."
          />
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {values.map((value, index) => (
              <Reveal key={value.title} delay={index * 90}>
                <article className="card h-full p-7 text-center">
                  <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-cyan-900/10 text-cyan-900">
                    <value.icon className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-extrabold text-slate-950">{value.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-600">{value.description}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 sm:py-24">
        <div className="section-container grid gap-5 lg:grid-cols-3">
          {[
            {
              title: 'رؤيتنا',
              text: 'أن تكون متابعة المطالبات المالية أكثر وضوحًا واحترافية، بحيث يعرف العميل حالته وخياراته في كل مرحلة.',
            },
            {
              title: 'أسلوبنا',
              text: 'نبدأ بفهم ملف المطالبة، ثم نحدد طريقة التواصل المناسبة، ونعمل على حلول عملية قبل التفكير في التصعيد.',
            },
            {
              title: 'التزامنا',
              text: 'الالتزام بالسرية، لغة التواصل الرسمية، وتقديم معلومات واضحة للعميل دون وعود مبالغ فيها أو أرقام غير موثقة.',
            },
          ].map((item, index) => (
            <Reveal key={item.title} delay={index * 100}>
              <div className="card h-full p-8">
                <h3 className="text-2xl font-extrabold text-slate-950">{item.title}</h3>
                <p className="mt-4 text-sm leading-8 text-slate-600">{item.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
      <CtaSection />
    </>
  );
}

function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="خدماتنا"
        icon={BriefcaseBusiness}
        title="خدمات متكاملة لمتابعة المستحقات المالية المتأخرة."
        subtitle="تغطي خدماتنا مراحل متابعة المطالبة، من فهم الملف والتواصل مع الطرف المدين إلى محاولة التسوية وتقديم تقرير واضح بالنتائج."
      />
      <section className="py-20 sm:py-24">
        <div className="section-container grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {services.map((service, index) => (
            <Reveal key={service.title} delay={index * 80}>
              <article className="card h-full p-7">
                <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-900 text-white">
                  <service.icon className="h-7 w-7" />
                </div>
                <h2 className="text-xl font-extrabold text-slate-950">{service.title}</h2>
                <p className="mt-3 text-sm leading-7 text-slate-600">{service.description}</p>
                <ul className="mt-5 space-y-3">
                  {service.points.map((point) => (
                    <li key={point} className="flex gap-3 text-sm font-semibold leading-7 text-slate-700">
                      <CheckCircle2 className="mt-1 h-5 w-5 flex-shrink-0 text-cyan-800" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </article>
            </Reveal>
          ))}
        </div>
      </section>
      <SectorsSection />
      <CtaSection />
    </>
  );
}

function ProcessPage() {
  return (
    <>
      <PageHero
        eyebrow="آلية العمل"
        icon={ListChecks}
        title="خطوات واضحة تجعل العميل يعرف ما الذي سيحدث بعد التواصل."
        subtitle="كل مطالبة تختلف عن الأخرى، لذلك يبدأ العمل بالفهم والمراجعة، ثم يتم اختيار أسلوب المتابعة المناسب وتوثيق النتائج."
      />
      <section className="py-20 sm:py-24">
        <div className="section-container">
          <div className="relative mx-auto max-w-5xl">
            <div className="absolute right-5 top-0 hidden h-full w-px bg-cyan-900/15 md:block" />
            <div className="space-y-5">
              {processSteps.map((step, index) => (
                <Reveal key={step.number} delay={index * 70}>
                  <div className="relative grid gap-4 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm md:grid-cols-[120px_1fr] md:p-7">
                    <div className="flex items-center gap-4 md:block">
                      <div className="relative z-10 inline-flex rounded-2xl bg-cyan-900 px-4 py-2 text-lg font-extrabold text-white">{step.number}</div>
                    </div>
                    <div>
                      <h2 className="text-2xl font-extrabold text-slate-950">{step.title}</h2>
                      <p className="mt-3 text-sm leading-8 text-slate-600 sm:text-base">{step.description}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>
      <CtaSection />
    </>
  );
}

function FaqPage() {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <>
      <PageHero
        eyebrow="الأسئلة الشائعة"
        icon={FileCheck2}
        title="إجابات مباشرة على أكثر الأسئلة التي تهم العميل قبل التواصل."
        subtitle="إجابات مختصرة تساعدك على فهم طبيعة الخدمة وحدودها قبل إرسال طلب التواصل الأولي."
      />
      <section className="py-20 sm:py-24">
        <div className="section-container">
          <div className="mx-auto max-w-4xl space-y-4">
            {faqItems.map((item, index) => {
              const isOpen = openIndex === index;
              return (
                <Reveal key={item.question} delay={index * 60}>
                  <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
                    <button
                      type="button"
                      onClick={() => setOpenIndex(isOpen ? -1 : index)}
                      className="flex w-full items-center justify-between gap-4 p-5 text-right sm:p-6"
                      aria-expanded={isOpen}
                    >
                      <span className="text-base font-extrabold text-slate-950 sm:text-lg">{item.question}</span>
                      <ChevronDown className={`h-5 w-5 flex-shrink-0 text-cyan-900 transition ${isOpen ? 'rotate-180' : ''}`} />
                    </button>
                    <div className={`faq-answer ${isOpen ? 'open' : ''}`}>
                      <p className="border-t border-slate-100 px-5 pb-6 pt-4 text-sm leading-8 text-slate-600 sm:px-6">{item.answer}</p>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>
      <CtaSection />
    </>
  );
}

function ContactPage() {
  const [sentMessage, setSentMessage] = useState('');

  const mailtoHref = useMemo(() => {
    const subject = encodeURIComponent('طلب استشارة في تحصيل المطالبات المالية');
    return `mailto:${company.email}?subject=${subject}`;
  }, []);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = String(form.get('name') || '').trim();
    const organization = String(form.get('organization') || '').trim();
    const phone = String(form.get('phone') || '').trim();
    const email = String(form.get('email') || '').trim();
    const claimType = String(form.get('claimType') || '').trim();
    const claimValue = String(form.get('claimValue') || '').trim();
    const message = String(form.get('message') || '').trim();

    const body = [
      'مرحبًا، أود طلب استشارة بخصوص متابعة مطالبات مالية.',
      `الاسم: ${name}`,
      `الشركة: ${organization}`,
      `رقم الجوال: ${phone}`,
      email ? `البريد: ${email}` : '',
      `نوع المطالبة: ${claimType}`,
      claimValue ? `القيمة التقريبية: ${claimValue}` : '',
      `ملخص الطلب: ${message}`,
    ]
      .filter(Boolean)
      .join('\n');

    const whatsappUrl = `https://wa.me/${company.phoneLink}?text=${encodeURIComponent(body)}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    setSentMessage('تم تجهيز الرسالة. يرجى مراجعتها في واتساب ثم إرسالها لإكمال طلب التواصل.');
    event.currentTarget.reset();
  }

  return (
    <>
      <PageHero
        eyebrow="تواصل معنا"
        icon={Mail}
        title="ابدأ بطلب استشارة أولية وسنساعدك في تحديد الخطوة المناسبة."
        subtitle="اكتب وصفًا مختصرًا للحالة دون إرسال مستندات حساسة من النموذج العام. سيتم ترتيب التفاصيل عبر قناة تواصل مناسبة عند الحاجة."
      />
      <section className="py-20 sm:py-24">
        <div className="section-container grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
          <Reveal>
            <div>
              <span className="section-eyebrow">
                <Send className="h-4 w-4" />
                بيانات التواصل
              </span>
              <h2 className="section-title">قنوات واضحة للتواصل السريع والرسمي.</h2>
              <p className="section-subtitle text-right">
                يمكنك التواصل مباشرة عبر الهاتف أو البريد، أو تعبئة النموذج ليتم تجهيز رسالة واتساب تحتوي بيانات طلبك بشكل منظم.
              </p>

              <div className="mt-8 space-y-4">
                <a href={`tel:${company.phoneLink}`} className="contact-card">
                  <div className="contact-icon">
                    <Phone className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-500">الهاتف</p>
                    <p className="font-extrabold text-slate-950">{company.phoneDisplay}</p>
                  </div>
                </a>
                <a href={mailtoHref} className="contact-card">
                  <div className="contact-icon">
                    <Mail className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-500">البريد الإلكتروني</p>
                    <p className="break-all font-extrabold text-slate-950">{company.email}</p>
                  </div>
                </a>
                <div className="contact-card">
                  <div className="contact-icon">
                    <MapPin className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-500">الموقع وساعات العمل</p>
                    <p className="font-extrabold text-slate-950">{company.location}</p>
                    <p className="mt-1 text-sm text-slate-500">{company.workingHours}</p>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <form onSubmit={handleSubmit} className="card p-6 sm:p-8">
              <div className="grid gap-5 sm:grid-cols-2">
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  الاسم الكامل
                  <input className="input-field" name="name" placeholder="اكتب اسمك" required />
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  اسم الشركة
                  <input className="input-field" name="organization" placeholder="اسم الشركة أو المؤسسة" required />
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  رقم الجوال
                  <input className="input-field" name="phone" placeholder="05xxxxxxxx" inputMode="tel" required />
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  البريد الإلكتروني
                  <input className="input-field" name="email" placeholder="name@example.com" type="email" />
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  نوع المطالبة
                  <select className="input-field" name="claimType" defaultValue="" required>
                    <option value="" disabled>
                      اختر نوع المطالبة
                    </option>
                    <option>مطالبات تجارية</option>
                    <option>فواتير متأخرة</option>
                    <option>عقود أو توريد</option>
                    <option>حالات متعددة تحتاج دراسة</option>
                    <option>استفسار عام</option>
                  </select>
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700">
                  القيمة التقريبية
                  <input className="input-field" name="claimValue" placeholder="اختياري" />
                </label>
                <label className="grid gap-2 text-sm font-bold text-slate-700 sm:col-span-2">
                  ملخص الطلب
                  <textarea className="input-field min-h-36 resize-y" name="message" placeholder="اكتب ملخصًا مختصرًا عن الحالة دون إرفاق بيانات حساسة جدًا" required />
                </label>
              </div>
              <button type="submit" className="primary-button mt-6 w-full">
                <MessageCircle className="h-5 w-5" />
                إرسال الطلب عبر واتساب
              </button>
              {sentMessage ? <p className="mt-4 rounded-2xl bg-cyan-50 p-4 text-sm font-bold leading-7 text-cyan-900">{sentMessage}</p> : null}
              <p className="mt-4 text-center text-xs leading-6 text-slate-500">
                يتم استخدام بيانات التواصل للرد على طلبك ومراجعة الاستفسار الأولي فقط.
              </p>
            </form>
          </Reveal>
        </div>
      </section>
    </>
  );
}

function PrivacyPage() {
  return (
    <>
      <PageHero
        eyebrow="سياسة الخصوصية"
        icon={LockKeyhole}
        title="التعامل مع بيانات العملاء باعتبارها معلومات حساسة."
        subtitle="توضح هذه السياسة طريقة استخدام بيانات التواصل والمعلومات الأولية التي يرسلها الزائر عبر الموقع."
      />
      <LegalContent
        items={[
          {
            title: 'استخدام البيانات',
            text: 'تستخدم بيانات نموذج التواصل للرد على الاستفسارات ومراجعة الطلب الأولي فقط، ولا تستخدم لأغراض تسويقية غير مرتبطة بطلب العميل إلا بموافقته.',
          },
          {
            title: 'سرية المطالبات',
            text: 'أي معلومات تتعلق بالمطالبات المالية أو الأطراف ذات العلاقة تعامل بسرية، ولا تتم مشاركتها إلا ضمن نطاق الخدمة أو وفق المتطلبات النظامية.',
          },
          {
            title: 'المستندات الحساسة',
            text: 'يفضل عدم إرسال مستندات مالية حساسة عبر نموذج عام. عند الحاجة إلى مستندات يتم تحديد قناة مناسبة لتبادلها مع الجهة المخولة.',
          },
          {
            title: 'تحديث السياسة',
            text: 'قد يتم تحديث سياسة الخصوصية عند إضافة خدمات جديدة أو تغيير آلية استقبال الطلبات، ويعد استمرار استخدام الموقع قبولًا بالسياسة المحدثة.',
          },
        ]}
      />
    </>
  );
}

function TermsPage() {
  return (
    <>
      <PageHero
        eyebrow="شروط الاستخدام"
        icon={FileText}
        title="معلومات الموقع تعريفية ولا تعد وعدًا بنتيجة محددة."
        subtitle="تحدد هذه الشروط طبيعة المعلومات المنشورة في الموقع وطريقة استخدام خدمات التواصل الأولي."
      />
      <LegalContent
        items={[
          {
            title: 'طبيعة المعلومات',
            text: 'المحتوى المنشور في الموقع يهدف إلى التعريف بالخدمات وطريقة العمل، ولا يعد ضمانًا لتحصيل أي مبلغ أو نتيجة محددة.',
          },
          {
            title: 'تقييم كل حالة',
            text: 'يتم تقييم كل مطالبة حسب مستنداتها وظروفها وقيمة المبلغ وطبيعة العلاقة بين الأطراف، ثم يتم تحديد المسار المناسب بعد المراجعة.',
          },
          {
            title: 'الرسوم ونطاق الخدمة',
            text: 'لا تعرض الرسوم بشكل ثابت في الموقع، ويتم تحديد نطاق الخدمة والتكلفة بعد فهم الطلب وتوضيح المتطلبات وموافقة العميل.',
          },
          {
            title: 'الاستخدام الصحيح للموقع',
            text: 'يجب على الزائر تقديم معلومات صحيحة عند التواصل، وعدم استخدام الموقع لإرسال بيانات تخص أطرافًا أخرى دون صفة أو تفويض مناسب.',
          },
        ]}
      />
    </>
  );
}

function LegalContent({ items }: { items: { title: string; text: string }[] }) {
  return (
    <section className="py-20 sm:py-24">
      <div className="section-container mx-auto max-w-4xl space-y-5">
        {items.map((item, index) => (
          <Reveal key={item.title} delay={index * 80}>
            <article className="card p-7 sm:p-8">
              <h2 className="text-2xl font-extrabold text-slate-950">{item.title}</h2>
              <p className="mt-4 text-sm leading-8 text-slate-600 sm:text-base">{item.text}</p>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-slate-950 py-10 text-white">
      <div className="section-container flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-cyan-600 text-lg font-extrabold">ش</div>
            <div>
              <p className="font-extrabold">{company.name}</p>
              <p className="text-sm text-slate-400">{company.slogan}</p>
            </div>
          </div>
          <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-400">
            حلول متابعة وتحصيل مطالبات مالية بأسلوب مهني، منظم، ويحافظ على سرية بيانات العملاء ووضوح الإجراءات.
          </p>
        </div>
        <div className="flex flex-wrap gap-3 text-sm font-bold text-slate-300">
          <RouteLink route="privacy" className="hover:text-white">الخصوصية</RouteLink>
          <span className="text-slate-600">/</span>
          <RouteLink route="terms" className="hover:text-white">الشروط</RouteLink>
          <span className="text-slate-600">/</span>
          <RouteLink route="contact" className="hover:text-white">تواصل معنا</RouteLink>
        </div>
      </div>
    </footer>
  );
}

function FloatingActions() {
  const message = encodeURIComponent('مرحبًا، أريد الاستفسار عن خدمات تحصيل المطالبات المالية.');
  return (
    <div className="fixed bottom-5 left-5 z-40 flex flex-col gap-3 print:hidden">
      <a
        href={`https://wa.me/${company.phoneLink}?text=${message}`}
        target="_blank"
        rel="noreferrer"
        className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-600 text-white shadow-xl shadow-emerald-900/20 transition hover:scale-105"
        aria-label="واتساب"
      >
        <MessageCircle className="h-6 w-6" />
      </a>
      <a
        href={`tel:${company.phoneLink}`}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-950 text-white shadow-xl shadow-slate-900/20 transition hover:scale-105"
        aria-label="اتصال"
      >
        <Phone className="h-6 w-6" />
      </a>
    </div>
  );
}

function CurrentPage({ route }: { route: RouteKey }) {
  if (route === 'about') return <AboutPage />;
  if (route === 'services') return <ServicesPage />;
  if (route === 'process') return <ProcessPage />;
  if (route === 'faq') return <FaqPage />;
  if (route === 'contact') return <ContactPage />;
  if (route === 'privacy') return <PrivacyPage />;
  if (route === 'terms') return <TermsPage />;
  return <HomePage />;
}

export default function App() {
  const route = useRoute();

  return (
    <main>
      <Navigation activeRoute={route} />
      <CurrentPage route={route} />
      <Footer />
      <FloatingActions />
    </main>
  );
}
